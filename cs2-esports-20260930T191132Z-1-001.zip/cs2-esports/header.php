<?php
/**
 * Header template.
 *
 * @package StrikeHub
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#primary-content"><?php esc_html_e( 'Skip to content', 'strikehub' ); ?></a>

<header id="masthead" class="site-header">
	<div class="header-row">
		<div class="site-branding">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<a class="site-title" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
			<?php endif; ?>
		</div>

		<nav id="primary-navigation" class="primary-navigation" aria-label="<?php esc_attr_e( 'Primary', 'strikehub' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'menu_class'     => 'nav-menu',
					'fallback_cb'    => 'strikehub_default_primary_menu',
				)
			);
			?>
		</nav>

		<div class="header-actions">
			<button type="button" class="icon-btn search-toggle" aria-haspopup="dialog" aria-expanded="false" aria-controls="search-overlay">
				<span class="screen-reader-text"><?php esc_html_e( 'Search', 'strikehub' ); ?></span>
				<svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="2"/><line x1="21" y1="21" x2="16.65" y2="16.65" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
			</button>
			<button type="button" class="icon-btn mobile-menu-toggle" aria-haspopup="true" aria-expanded="false" aria-controls="mobile-menu">
				<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'strikehub' ); ?></span>
				<svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true"><line x1="3" y1="6" x2="21" y2="6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><line x1="3" y1="12" x2="21" y2="12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><line x1="3" y1="18" x2="21" y2="18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
			</button>
		</div>
	</div>

	<?php if ( get_theme_mod( 'enable_secondary_nav', true ) ) : ?>
		<nav class="secondary-navigation" aria-label="<?php esc_attr_e( 'Secondary', 'strikehub' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'secondary',
					'container'      => false,
					'menu_class'     => 'nav-menu nav-menu-secondary',
					'fallback_cb'    => false,
				)
			);
			?>
		</nav>
	<?php endif; ?>

	<?php strikehub_breaking_ticker(); ?>
</header>

<div id="mobile-menu" class="mobile-menu" aria-hidden="true">
	<div class="mobile-menu-inner">
		<button type="button" class="icon-btn mobile-menu-close" aria-label="<?php esc_attr_e( 'Close menu', 'strikehub' ); ?>">&times;</button>
		<nav aria-label="<?php esc_attr_e( 'Mobile', 'strikehub' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'mobile',
					'container'      => false,
					'menu_class'     => 'nav-menu-mobile',
					'fallback_cb'    => 'strikehub_default_primary_menu',
				)
			);
			?>
		</nav>
	</div>
</div>

<div id="search-overlay" class="search-overlay" role="dialog" aria-modal="true" aria-hidden="true" aria-label="<?php esc_attr_e( 'Site search', 'strikehub' ); ?>">
	<div class="search-overlay-inner">
		<button type="button" class="icon-btn search-close" aria-label="<?php esc_attr_e( 'Close search', 'strikehub' ); ?>">&times;</button>
		<form role="search" method="get" class="search-overlay-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<input type="search" id="strikehub-search-input" name="s" placeholder="<?php esc_attr_e( 'Search news, players, teams, events…', 'strikehub' ); ?>" autocomplete="off">
		</form>
		<div id="search-live-results" class="search-live-results" aria-live="polite"></div>
	</div>
</div>

<?php
/**
 * Fallback primary menu so the header is usable before an admin has
 * created a real WordPress menu.
 */
function strikehub_default_primary_menu() {
	$links = array(
		home_url( '/' )                       => __( 'Home', 'strikehub' ),
		home_url( '/news/' )                  => __( 'News', 'strikehub' ),
		get_post_type_archive_link( 'cs2_match' ) => __( 'Matches', 'strikehub' ),
		home_url( '/events/' )                => __( 'Events', 'strikehub' ),
		home_url( '/players/' )               => __( 'Players', 'strikehub' ),
		home_url( '/teams/' )                 => __( 'Teams', 'strikehub' ),
	);
	echo '<ul class="nav-menu">';
	foreach ( $links as $url => $label ) {
		if ( $url ) {
			echo '<li><a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a></li>';
		}
	}
	echo '</ul>';
}
?>
<div id="primary-content" class="site-content">
