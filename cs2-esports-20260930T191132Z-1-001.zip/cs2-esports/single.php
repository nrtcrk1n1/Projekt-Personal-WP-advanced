<?php
/**
 * Single post template.
 *
 * @package StrikeHub
 */

get_header();
?>
<div class="layout-three-col">
	<main id="main" class="main-content">
		<?php strikehub_breadcrumbs(); ?>

		<?php
		while ( have_posts() ) :
			the_post();
			$categories = get_the_category();
			?>
			<article <?php post_class( 'single-article' ); ?>>
				<header class="article-header">
					<?php if ( $categories ) : ?>
						<a class="article-category" href="<?php echo esc_url( get_category_link( $categories[0]->term_id ) ); ?>"><?php echo esc_html( $categories[0]->name ); ?></a>
					<?php endif; ?>
					<h1 class="article-title"><?php the_title(); ?></h1>
					<?php if ( has_excerpt() ) : ?>
						<p class="article-subtitle"><?php echo esc_html( get_the_excerpt() ); ?></p>
					<?php endif; ?>
					<div class="article-meta">
						<span class="article-author">
							<?php esc_html_e( 'By', 'strikehub' ); ?>
							<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php the_author(); ?></a>
						</span>
						<span aria-hidden="true">&middot;</span>
						<span><?php echo esc_html( get_the_date() ); ?></span>
						<?php if ( get_the_modified_date() !== get_the_date() ) : ?>
							<span aria-hidden="true">&middot;</span>
							<span><?php esc_html_e( 'Updated', 'strikehub' ); ?> <?php echo esc_html( get_the_modified_date() ); ?></span>
						<?php endif; ?>
						<span aria-hidden="true">&middot;</span>
						<span><?php echo esc_html( strikehub_reading_time() ); ?></span>
						<span aria-hidden="true">&middot;</span>
						<span><?php echo esc_html( strikehub_get_views( get_the_ID() ) ); ?> <?php esc_html_e( 'views', 'strikehub' ); ?></span>
					</div>
				</header>

				<?php if ( has_post_thumbnail() ) : ?>
					<figure class="article-featured-image">
						<?php the_post_thumbnail( 'strikehub-hero', array( 'loading' => 'eager' ) ); ?>
					</figure>
				<?php endif; ?>

				<div class="article-content">
					<?php the_content(); ?>
				</div>

				<footer class="article-footer">
					<?php
					$tags = get_the_tags();
					if ( $tags ) :
						?>
						<div class="article-tags">
							<?php foreach ( $tags as $tag ) : ?>
								<a href="<?php echo esc_url( get_tag_link( $tag ) ); ?>" class="tag-pill"><?php echo esc_html( $tag->name ); ?></a>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>

					<div class="share-row" aria-label="<?php esc_attr_e( 'Share this article', 'strikehub' ); ?>">
						<span><?php esc_html_e( 'Share:', 'strikehub' ); ?></span>
						<a target="_blank" rel="noopener" href="https://twitter.com/intent/tweet?url=<?php echo rawurlencode( get_permalink() ); ?>&text=<?php echo rawurlencode( get_the_title() ); ?>"><?php esc_html_e( 'X / Twitter', 'strikehub' ); ?></a>
						<a target="_blank" rel="noopener" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo rawurlencode( get_permalink() ); ?>"><?php esc_html_e( 'Facebook', 'strikehub' ); ?></a>
						<button type="button" class="copy-link-btn" data-copy-link="<?php echo esc_url( get_permalink() ); ?>"><?php esc_html_e( 'Copy Link', 'strikehub' ); ?></button>
					</div>
				</footer>

				<?php
				$related = new WP_Query(
					array(
						'category__in'   => wp_list_pluck( $categories, 'term_id' ),
						'post__not_in'   => array( get_the_ID() ),
						'posts_per_page' => 3,
						'no_found_rows'  => true,
					)
				);
				if ( $related->have_posts() ) :
					?>
					<section class="related-articles">
						<h2><?php esc_html_e( 'Related Articles', 'strikehub' ); ?></h2>
						<div class="news-grid">
							<?php
							while ( $related->have_posts() ) :
								$related->the_post();
								get_template_part( 'template-parts/news-card' );
							endwhile;
							wp_reset_postdata();
							?>
						</div>
					</section>
					<?php
				endif;
				?>

				<?php if ( comments_open() || get_comments_number() ) : ?>
					<?php comments_template(); ?>
				<?php endif; ?>
			</article>
			<?php
		endwhile;
		?>
	</main>

	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
