<?php
/**
 * "CS2 Esports Dashboard" admin page + scoring settings screen.
 *
 * @package StrikeHub
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function strikehub_admin_menu() {
	add_menu_page(
		__( 'CS2 Esports Dashboard', 'strikehub' ),
		__( 'CS2 Dashboard', 'strikehub' ),
		'manage_options',
		'strikehub-dashboard',
		'strikehub_render_dashboard_page',
		'dashicons-chart-bar',
		3
	);

	add_submenu_page(
		'strikehub-dashboard',
		__( 'Ranking Settings', 'strikehub' ),
		__( 'Ranking Settings', 'strikehub' ),
		'manage_options',
		'strikehub-ranking-settings',
		'strikehub_render_settings_page'
	);
}
add_action( 'admin_menu', 'strikehub_admin_menu' );

function strikehub_render_dashboard_page() {
	$counts_news   = wp_count_posts( 'post' );
	$counts_match  = wp_count_posts( 'cs2_match' );
	$counts_team   = wp_count_posts( 'team' );
	$counts_player = wp_count_posts( 'player' );
	$counts_event  = wp_count_posts( 'event' );

	$live_matches = strikehub_get_matches_by_status( 'live', 999 )->found_posts;

	$top_teams   = cs2_get_top_teams_today( 1 );
	$top_team    = $top_teams ? get_the_title( $top_teams[0]['team_id'] ) : __( 'No data available', 'strikehub' );

	$top_players = cs2_get_players_of_the_day( 1 );
	$top_player  = $top_players ? get_the_title( $top_players[0]['player_id'] ) : __( 'No data available', 'strikehub' );

	$latest_transfer = get_posts( array( 'post_type' => 'transfer', 'posts_per_page' => 1 ) );
	?>
	<div class="wrap strikehub-dashboard">
		<h1><?php esc_html_e( 'CS2 Esports Dashboard', 'strikehub' ); ?></h1>

		<?php if ( isset( $_GET['strikehub_recalculated'] ) ) : ?>
			<div class="notice notice-success"><p><?php esc_html_e( 'Rankings recalculated.', 'strikehub' ); ?></p></div>
		<?php endif; ?>

		<h2><?php esc_html_e( 'Today', 'strikehub' ); ?></h2>
		<table class="widefat striped" style="max-width:480px">
			<tbody>
				<tr><td><?php esc_html_e( 'News', 'strikehub' ); ?></td><td><?php echo esc_html( $counts_news->publish ); ?></td></tr>
				<tr><td><?php esc_html_e( 'Matches', 'strikehub' ); ?></td><td><?php echo esc_html( $counts_match->publish ); ?></td></tr>
				<tr><td><?php esc_html_e( 'Live Matches', 'strikehub' ); ?></td><td><?php echo esc_html( $live_matches ); ?></td></tr>
				<tr><td><?php esc_html_e( 'Teams', 'strikehub' ); ?></td><td><?php echo esc_html( $counts_team->publish ); ?></td></tr>
				<tr><td><?php esc_html_e( 'Players', 'strikehub' ); ?></td><td><?php echo esc_html( $counts_player->publish ); ?></td></tr>
				<tr><td><?php esc_html_e( 'Events', 'strikehub' ); ?></td><td><?php echo esc_html( $counts_event->publish ); ?></td></tr>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Top Team', 'strikehub' ); ?></h2>
		<p><?php echo esc_html( $top_team ); ?></p>

		<h2><?php esc_html_e( 'Top Player', 'strikehub' ); ?></h2>
		<p><?php echo esc_html( $top_player ); ?></p>

		<h2><?php esc_html_e( 'Latest Transfer', 'strikehub' ); ?></h2>
		<p>
			<?php
			if ( $latest_transfer ) {
				echo esc_html( get_the_title( $latest_transfer[0] ) );
			} else {
				esc_html_e( 'No data available', 'strikehub' );
			}
			?>
		</p>

		<h2><?php esc_html_e( 'Quick Actions', 'strikehub' ); ?></h2>
		<p class="strikehub-quick-actions">
			<a class="button" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=post' ) ); ?>"><?php esc_html_e( 'Add News', 'strikehub' ); ?></a>
			<a class="button" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=cs2_match' ) ); ?>"><?php esc_html_e( 'Add Match', 'strikehub' ); ?></a>
			<a class="button" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=player' ) ); ?>"><?php esc_html_e( 'Add Player', 'strikehub' ); ?></a>
			<a class="button" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=team' ) ); ?>"><?php esc_html_e( 'Add Team', 'strikehub' ); ?></a>
			<a class="button" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=event' ) ); ?>"><?php esc_html_e( 'Add Event', 'strikehub' ); ?></a>
			<a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=strikehub_recalculate' ), 'strikehub_recalculate' ) ); ?>">
				<?php esc_html_e( 'Recalculate Rankings', 'strikehub' ); ?>
			</a>
		</p>
	</div>
	<?php
}

function strikehub_render_settings_page() {
	$scoring = strikehub_get_scoring();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'CS2 Ranking Settings', 'strikehub' ); ?></h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'strikehub_scoring_group' ); ?>
			<h2><?php esc_html_e( 'Scoring Weights', 'strikehub' ); ?></h2>
			<table class="form-table">
				<?php foreach ( strikehub_scoring_defaults() as $key => $default ) : ?>
					<tr>
						<th><label for="strikehub_scoring_<?php echo esc_attr( $key ); ?>"><?php echo esc_html( ucwords( str_replace( '_', ' ', $key ) ) ); ?></label></th>
						<td>
							<input type="number" step="0.5" id="strikehub_scoring_<?php echo esc_attr( $key ); ?>"
								name="strikehub_scoring[<?php echo esc_attr( $key ); ?>]"
								value="<?php echo esc_attr( $scoring[ $key ] ); ?>">
						</td>
					</tr>
				<?php endforeach; ?>
			</table>

			<h2><?php esc_html_e( '"Teams on Fire" Settings', 'strikehub' ); ?></h2>
			<table class="form-table">
				<tr>
					<th><label for="strikehub_fire_matches_count"><?php esc_html_e( 'Recent matches considered', 'strikehub' ); ?></label></th>
					<td>
						<select id="strikehub_fire_matches_count" name="strikehub_fire_matches_count">
							<?php foreach ( array( 5, 10, 20 ) as $n ) : ?>
								<option value="<?php echo esc_attr( $n ); ?>" <?php selected( (int) get_option( 'strikehub_fire_matches_count', 5 ), $n ); ?>><?php echo esc_html( $n ); ?></option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'REST API', 'strikehub' ); ?></h2>
			<table class="form-table">
				<tr>
					<th><?php esc_html_e( 'Enable public REST endpoints', 'strikehub' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="strikehub_enable_rest" value="1" <?php checked( strikehub_rest_enabled() ); ?>>
							<?php esc_html_e( 'Expose /wp-json/cs2/v1/... read-only endpoints publicly', 'strikehub' ); ?>
						</label>
					</td>
				</tr>
			</table>

			<?php submit_button(); ?>
		</form>

		<p>
			<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=strikehub_recalculate' ), 'strikehub_recalculate' ) ); ?>">
				<?php esc_html_e( "Recalculate Today's Rankings", 'strikehub' ); ?>
			</a>
		</p>
	</div>
	<?php
}

/**
 * The REST toggle isn't part of register_setting() above because it needs
 * to live on the same form without its own settings group collision; save
 * it manually alongside the others.
 */
function strikehub_save_rest_toggle() {
	if ( ! isset( $_POST['option_page'] ) || 'strikehub_scoring_group' !== $_POST['option_page'] ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	check_admin_referer( 'strikehub_scoring_group-options' );
	update_option( 'strikehub_enable_rest', ! empty( $_POST['strikehub_enable_rest'] ) );
}
add_action( 'admin_init', 'strikehub_save_rest_toggle', 20 );

/**
 * Native dashboard widget summarising the same data, for editors who live
 * on wp-admin/index.php.
 */
function strikehub_register_dashboard_widget() {
	wp_add_dashboard_widget( 'strikehub_dashboard_widget', __( 'CS2 Esports Snapshot', 'strikehub' ), 'strikehub_render_dashboard_widget' );
}
add_action( 'wp_dashboard_setup', 'strikehub_register_dashboard_widget' );

function strikehub_render_dashboard_widget() {
	$top_teams = cs2_get_top_teams_today( 3 );
	if ( ! $top_teams ) {
		strikehub_no_data();
		return;
	}
	echo '<ol>';
	foreach ( $top_teams as $row ) {
		echo '<li>' . esc_html( get_the_title( $row['team_id'] ) ) . ' &mdash; ' . esc_html( $row['score'] ) . ' pts</li>';
	}
	echo '</ol>';
}
