<?php
/**
 * Daily ranking / "on fire" / trending calculation engine.
 *
 * Nothing here invents data: every score is derived from post meta the
 * admin has actually entered (match results, team stats). If a team has
 * no matches or stats, it will not appear, rather than being scored 0
 * and presented as if it were a real result.
 *
 * @package StrikeHub
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* -------------------------------------------------------------------- */
/* Scoring configuration (editable from wp-admin)                        */
/* -------------------------------------------------------------------- */

function strikehub_scoring_defaults() {
	return array(
		'match_win'           => 10,
		'match_loss'          => -5,
		'map_win'             => 2,
		'map_loss'            => 0,
		'tournament_win'      => 50,
		'tournament_final'    => 30,
		'tournament_semifinal'=> 20,
		'win_streak_bonus'    => 5,
	);
}

function strikehub_get_scoring() {
	$saved = get_option( 'strikehub_scoring', array() );
	return wp_parse_args( $saved, strikehub_scoring_defaults() );
}

function strikehub_register_scoring_settings() {
	register_setting( 'strikehub_scoring_group', 'strikehub_scoring', array( 'sanitize_callback' => 'strikehub_sanitize_scoring' ) );
	register_setting( 'strikehub_scoring_group', 'strikehub_fire_matches_count', array( 'sanitize_callback' => 'absint', 'default' => 5 ) );
}
add_action( 'admin_init', 'strikehub_register_scoring_settings' );

function strikehub_sanitize_scoring( $input ) {
	$clean = array();
	foreach ( strikehub_scoring_defaults() as $key => $default ) {
		$clean[ $key ] = isset( $input[ $key ] ) && is_numeric( $input[ $key ] ) ? floatval( $input[ $key ] ) : $default;
	}
	return $clean;
}

/* -------------------------------------------------------------------- */
/* Core daily team score                                                  */
/* -------------------------------------------------------------------- */

/**
 * cs2_calculate_team_daily_score( $team_id )
 *
 * Combines match wins/losses, map differential, win streak, and last
 * tournament result (all admin-entered team meta) using the configurable
 * weight table above. Purely a function of stored data - no randomness.
 */
function cs2_calculate_team_daily_score( $team_id ) {
	$team_id = absint( $team_id );
	if ( ! $team_id || 'team' !== get_post_type( $team_id ) ) {
		return null;
	}

	$weights = strikehub_get_scoring();

	$wins       = (int) strikehub_meta( $team_id, '_wins', 0 );
	$losses     = (int) strikehub_meta( $team_id, '_losses', 0 );
	$map_wins   = (int) strikehub_meta( $team_id, '_map_wins', 0 );
	$map_losses = (int) strikehub_meta( $team_id, '_map_losses', 0 );
	$streak     = (int) strikehub_meta( $team_id, '_win_streak', 0 );
	$last_result = strikehub_meta( $team_id, '_last_tournament_result', '' );

	// A team with no recorded wins, losses, or maps has no basis for a
	// score - treat as "no data" rather than a synthetic zero.
	if ( 0 === $wins && 0 === $losses && 0 === $map_wins && 0 === $map_losses ) {
		return null;
	}

	$score  = 0;
	$score += $wins * $weights['match_win'];
	$score += $losses * $weights['match_loss'];
	$score += $map_wins * $weights['map_win'];
	$score += $map_losses * $weights['map_loss'];

	if ( $streak >= 2 ) {
		$score += $weights['win_streak_bonus'] * ( $streak - 1 );
	}

	if ( 'win' === $last_result ) {
		$score += $weights['tournament_win'];
	} elseif ( 'final' === $last_result ) {
		$score += $weights['tournament_final'];
	} elseif ( 'semifinal' === $last_result ) {
		$score += $weights['tournament_semifinal'];
	}

	return round( $score, 2 );
}

/**
 * Compute (or fetch from transient cache) today's Top N teams.
 * Returns an array of arrays: team_id, score, wins, losses, movement, is_new.
 */
function cs2_get_top_teams_today( $limit = 10 ) {
	$today_key = 'cs2_top_teams_' . current_time( 'Y_m_d' );
	$cached    = get_transient( $today_key );
	if ( false !== $cached ) {
		return array_slice( $cached, 0, $limit );
	}

	$teams_query = strikehub_get_teams();
	$scored      = array();

	foreach ( $teams_query->posts as $team ) {
		$score = cs2_calculate_team_daily_score( $team->ID );
		if ( null === $score ) {
			continue; // No usable data for this team today.
		}
		$scored[] = array(
			'team_id' => $team->ID,
			'score'   => $score,
			'wins'    => (int) strikehub_meta( $team->ID, '_wins', 0 ),
			'losses'  => (int) strikehub_meta( $team->ID, '_losses', 0 ),
		);
	}

	usort(
		$scored,
		function ( $a, $b ) {
			return $b['score'] <=> $a['score'];
		}
	);

	// Movement vs yesterday's cached positions, if we have them.
	$yesterday_key = 'cs2_team_positions_' . gmdate( 'Y_m_d', current_time( 'timestamp', true ) - DAY_IN_SECONDS );
	$prev_positions = get_transient( $yesterday_key );
	$prev_positions = is_array( $prev_positions ) ? $prev_positions : array();

	foreach ( $scored as $i => &$row ) {
		$position           = $i + 1;
		$row['position']    = $position;
		if ( isset( $prev_positions[ $row['team_id'] ] ) ) {
			$row['movement'] = $prev_positions[ $row['team_id'] ] - $position;
			$row['is_new']   = false;
		} else {
			$row['movement'] = 0;
			$row['is_new']   = ! empty( $prev_positions );
		}
	}
	unset( $row );

	set_transient( $today_key, $scored, DAY_IN_SECONDS );

	// Store today's positions for tomorrow's movement calculation.
	$positions_today = array();
	foreach ( $scored as $row ) {
		$positions_today[ $row['team_id'] ] = $row['position'];
	}
	set_transient( 'cs2_team_positions_' . current_time( 'Y_m_d' ), $positions_today, 2 * DAY_IN_SECONDS );

	return array_slice( $scored, 0, $limit );
}

function strikehub_clear_ranking_cache() {
	delete_transient( 'cs2_top_teams_' . current_time( 'Y_m_d' ) );
}

/* -------------------------------------------------------------------- */
/* Players of the Day                                                    */
/* -------------------------------------------------------------------- */

function cs2_get_players_of_the_day( $limit = 5 ) {
	$cache_key = 'cs2_players_of_day_' . current_time( 'Y_m_d' );
	$cached    = get_transient( $cache_key );
	if ( false !== $cached ) {
		return array_slice( $cached, 0, $limit );
	}

	$players = strikehub_get_players();
	$scored  = array();

	foreach ( $players->posts as $player ) {
		$rating = strikehub_meta( $player->ID, '_rating', '' );
		if ( '' === $rating ) {
			continue; // No stats entered - skip rather than fabricate.
		}
		$scored[] = array(
			'player_id' => $player->ID,
			'rating'    => (float) $rating,
			'kd'        => (float) strikehub_meta( $player->ID, '_kd', 0 ),
			'adr'       => (float) strikehub_meta( $player->ID, '_adr', 0 ),
		);
	}

	usort(
		$scored,
		function ( $a, $b ) {
			return $b['rating'] <=> $a['rating'];
		}
	);

	set_transient( $cache_key, $scored, DAY_IN_SECONDS );

	return array_slice( $scored, 0, $limit );
}

/* -------------------------------------------------------------------- */
/* Teams on Fire (recent form from actual match results)                 */
/* -------------------------------------------------------------------- */

/**
 * Returns 'W', 'L', or null (unclear/void) for $team_id in $match post.
 */
function strikehub_match_result_for_team( $match, $team_id ) {
	$team1 = (int) strikehub_meta( $match->ID, '_team1_id', 0 );
	$team2 = (int) strikehub_meta( $match->ID, '_team2_id', 0 );
	$score1 = strikehub_meta( $match->ID, '_score1', '' );
	$score2 = strikehub_meta( $match->ID, '_score2', '' );
	$status = strikehub_meta( $match->ID, '_status', '' );

	if ( 'final' !== $status || '' === $score1 || '' === $score2 ) {
		return null;
	}
	if ( (int) $team_id === $team1 ) {
		return ( (int) $score1 > (int) $score2 ) ? 'W' : 'L';
	}
	if ( (int) $team_id === $team2 ) {
		return ( (int) $score2 > (int) $score1 ) ? 'W' : 'L';
	}
	return null;
}

/**
 * Team form guide: array of 'W'/'L' for the last N finished matches,
 * most recent last (so it reads left-to-right chronologically).
 */
function strikehub_get_team_form( $team_id, $count = 5 ) {
	$matches = strikehub_get_team_matches( $team_id, $count * 3 ); // over-fetch, filter to finished
	$form    = array();
	foreach ( $matches->posts as $match ) {
		$result = strikehub_match_result_for_team( $match, $team_id );
		if ( null !== $result ) {
			$form[] = $result;
		}
		if ( count( $form ) >= $count ) {
			break;
		}
	}
	return array_reverse( $form );
}

/**
 * Teams whose current streak (from stored win_streak meta) meets or
 * exceeds a "hot" threshold, OR who have won most of their last N matches.
 */
function cs2_get_teams_on_fire( $limit = 5 ) {
	$recent_count = (int) get_option( 'strikehub_fire_matches_count', 5 );
	$teams        = strikehub_get_teams();
	$fire         = array();

	foreach ( $teams->posts as $team ) {
		$streak = (int) strikehub_meta( $team->ID, '_win_streak', 0 );
		$form   = strikehub_get_team_form( $team->ID, $recent_count );
		$win_count = count( array_filter( $form, fn( $r ) => 'W' === $r ) );

		if ( $streak >= 3 || ( count( $form ) >= 3 && $win_count / count( $form ) >= 0.7 ) ) {
			$fire[] = array(
				'team_id'   => $team->ID,
				'streak'    => $streak,
				'form'      => $form,
				'win_count' => $win_count,
				'played'    => count( $form ),
			);
		}
	}

	usort( $fire, fn( $a, $b ) => $b['streak'] <=> $a['streak'] );

	return array_slice( $fire, 0, $limit );
}

/* -------------------------------------------------------------------- */
/* Rising teams (score/position improved vs. yesterday)                  */
/* -------------------------------------------------------------------- */

function cs2_get_rising_teams( $limit = 5 ) {
	$today = cs2_get_top_teams_today( 999 );
	$rising = array_filter( $today, fn( $r ) => $r['movement'] > 0 );
	usort( $rising, fn( $a, $b ) => $b['movement'] <=> $a['movement'] );
	return array_slice( array_values( $rising ), 0, $limit );
}

/* -------------------------------------------------------------------- */
/* Trending (views/search-derived, clearly not "real-world popularity")  */
/* -------------------------------------------------------------------- */

function cs2_get_trending_articles( $limit = 5 ) {
	$q = strikehub_get_popular_news( $limit );
	return $q->posts;
}

/* -------------------------------------------------------------------- */
/* Admin: recalculate button                                             */
/* -------------------------------------------------------------------- */

function strikehub_handle_recalculate() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Insufficient permissions.', 'strikehub' ) );
	}
	check_admin_referer( 'strikehub_recalculate' );

	delete_transient( 'cs2_top_teams_' . current_time( 'Y_m_d' ) );
	delete_transient( 'cs2_players_of_day_' . current_time( 'Y_m_d' ) );

	wp_safe_redirect( add_query_arg( 'strikehub_recalculated', '1', wp_get_referer() ? wp_get_referer() : admin_url() ) );
	exit;
}
add_action( 'admin_post_strikehub_recalculate', 'strikehub_handle_recalculate' );

/**
 * Cron-free "day change" handling: because the transient key itself is
 * date-based (cs2_top_teams_Y_m_d), a new day automatically produces a
 * cache miss and triggers recalculation on the next page view - no
 * scheduled event required.
 */
