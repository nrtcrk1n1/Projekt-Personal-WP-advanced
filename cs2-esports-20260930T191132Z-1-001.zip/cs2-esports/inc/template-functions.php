<?php
/**
 * Template helper tags: breaking ticker, match summary rows, pagination.
 *
 * @package StrikeHub
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Breaking news ticker. Pulls the 5 most recent posts in the "breaking-news"
 * category if it exists; otherwise falls back to the 5 most recent posts.
 * Renders nothing (not fake headlines) if there is no content at all.
 */
function strikehub_breaking_ticker() {
	if ( ! get_theme_mod( 'enable_ticker', true ) ) {
		return;
	}

	$args = array( 'posts_per_page' => 5, 'no_found_rows' => true, 'ignore_sticky_posts' => true );
	if ( term_exists( 'breaking-news', 'category' ) ) {
		$args['category_name'] = 'breaking-news';
	}
	$q = new WP_Query( $args );

	if ( ! $q->have_posts() ) {
		return;
	}
	?>
	<div class="breaking-ticker" role="marquee" aria-label="<?php esc_attr_e( 'Breaking news', 'strikehub' ); ?>">
		<span class="breaking-label"><?php esc_html_e( 'Breaking', 'strikehub' ); ?></span>
		<div class="breaking-track">
			<ul class="breaking-list">
				<?php
				while ( $q->have_posts() ) :
					$q->the_post();
					?>
					<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
					<?php
				endwhile;
				?>
			</ul>
		</div>
	</div>
	<?php
	wp_reset_postdata();
}

/**
 * Numeric pagination for archive/search templates.
 */
function strikehub_pagination() {
	$big  = 999999999;
	$link = paginate_links(
		array(
			'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			'current'   => max( 1, get_query_var( 'paged' ) ),
			'total'     => $GLOBALS['wp_query']->max_num_pages,
			'prev_text' => __( '&laquo; Prev', 'strikehub' ),
			'next_text' => __( 'Next &raquo;', 'strikehub' ),
			'type'      => 'list',
		)
	);
	if ( $link ) {
		echo '<nav class="pagination" aria-label="' . esc_attr__( 'Posts navigation', 'strikehub' ) . '">' . wp_kses_post( $link ) . '</nav>';
	}
}

/**
 * Convenience accessor bundling a match's core display data. Centralising
 * this means match-card.php and the match single template never drift.
 */
function strikehub_get_match_data( $match_id ) {
	$team1_id = (int) strikehub_meta( $match_id, '_team1_id' );
	$team2_id = (int) strikehub_meta( $match_id, '_team2_id' );
	$event_id = (int) strikehub_meta( $match_id, '_event_id' );

	return array(
		'team1_id'   => $team1_id,
		'team2_id'   => $team2_id,
		'team1_name' => $team1_id ? get_the_title( $team1_id ) : __( 'TBD', 'strikehub' ),
		'team2_name' => $team2_id ? get_the_title( $team2_id ) : __( 'TBD', 'strikehub' ),
		'event_id'   => $event_id,
		'event_name' => $event_id ? get_the_title( $event_id ) : '',
		'date'       => strikehub_meta( $match_id, '_match_date' ),
		'time'       => strikehub_meta( $match_id, '_match_time' ),
		'format'     => strtoupper( strikehub_meta( $match_id, '_format', '' ) ),
		'status'     => strikehub_meta( $match_id, '_status', 'upcoming' ),
		'score1'     => strikehub_meta( $match_id, '_score1' ),
		'score2'     => strikehub_meta( $match_id, '_score2' ),
		'maps_raw'   => strikehub_meta( $match_id, '_maps' ),
	);
}

/**
 * Parses the "MapName Score1-Score2" per-line maps field into structured rows.
 */
function strikehub_parse_maps( $raw ) {
	$rows = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		if ( preg_match( '/^(.+?)\s+(\d+)\s*-\s*(\d+)$/', $line, $m ) ) {
			$rows[] = array( 'map' => trim( $m[1] ), 'score1' => (int) $m[2], 'score2' => (int) $m[3] );
		}
	}
	return $rows;
}

/**
 * Track post views on singular views of any public post type.
 */
add_action(
	'wp_head',
	function () {
		if ( is_singular() ) {
			strikehub_track_view( get_the_ID() );
		}
	}
);

/**
 * Article JSON-LD (NewsArticle) for standard posts.
 */
add_action(
	'wp_footer',
	function () {
		if ( ! is_singular( 'post' ) ) {
			return;
		}
		$post_id = get_the_ID();
		$data    = array(
			'@context'      => 'https://schema.org',
			'@type'         => 'NewsArticle',
			'headline'      => get_the_title( $post_id ),
			'datePublished' => get_the_date( DATE_W3C, $post_id ),
			'dateModified'  => get_the_modified_date( DATE_W3C, $post_id ),
			'author'        => array( '@type' => 'Person', 'name' => get_the_author_meta( 'display_name', get_post_field( 'post_author', $post_id ) ) ),
			'mainEntityOfPage' => get_permalink( $post_id ),
		);
		if ( has_post_thumbnail( $post_id ) ) {
			$data['image'] = wp_get_attachment_image_url( get_post_thumbnail_id( $post_id ), 'strikehub-hero' );
		}
		echo '<script type="application/ld+json">' . wp_json_encode( $data ) . '</script>';
	}
);

/**
 * Person schema for player profiles, SportsTeam for teams, Event for events.
 */
add_action(
	'wp_footer',
	function () {
		if ( is_singular( 'player' ) ) {
			$id   = get_the_ID();
			$data = array(
				'@context'    => 'https://schema.org',
				'@type'       => 'Person',
				'name'        => strikehub_meta( $id, '_real_name', get_the_title( $id ) ),
				'alternateName' => strikehub_meta( $id, '_nickname', get_the_title( $id ) ),
				'nationality' => strikehub_meta( $id, '_country' ),
			);
			echo '<script type="application/ld+json">' . wp_json_encode( $data ) . '</script>';
		} elseif ( is_singular( 'team' ) ) {
			$id   = get_the_ID();
			$data = array(
				'@context' => 'https://schema.org',
				'@type'    => 'SportsTeam',
				'name'     => get_the_title( $id ),
				'sport'    => 'Esports',
			);
			echo '<script type="application/ld+json">' . wp_json_encode( $data ) . '</script>';
		} elseif ( is_singular( 'event' ) ) {
			$id   = get_the_ID();
			$data = array(
				'@context'  => 'https://schema.org',
				'@type'     => 'Event',
				'name'      => get_the_title( $id ),
				'startDate' => strikehub_meta( $id, '_start_date' ),
				'endDate'   => strikehub_meta( $id, '_end_date' ),
				'location'  => array( '@type' => 'Place', 'name' => strikehub_meta( $id, '_location' ) ),
			);
			echo '<script type="application/ld+json">' . wp_json_encode( $data ) . '</script>';
		}
	}
);
