<?php
/**
 * Misc setup: cleanup, excerpt tuning, breadcrumbs.
 *
 * @package StrikeHub
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Remove default WP head clutter we don't need.
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'rsd_link' );

/**
 * Custom excerpt length & ellipsis for news cards.
 */
add_filter(
	'excerpt_length',
	function () {
		return 24;
	},
	999
);
add_filter(
	'excerpt_more',
	function () {
		return '&hellip;';
	}
);

/**
 * Simple breadcrumb renderer used on single/archive templates.
 * Outputs an ordered list with BreadcrumbList JSON-LD for SEO.
 */
function strikehub_breadcrumbs() {
	if ( is_front_page() ) {
		return;
	}

	$items = array(
		array(
			'label' => __( 'Home', 'strikehub' ),
			'url'   => home_url( '/' ),
		),
	);

	if ( is_singular( 'player' ) ) {
		$items[] = array( 'label' => __( 'Players', 'strikehub' ), 'url' => get_post_type_archive_link( 'player' ) );
		$items[] = array( 'label' => get_the_title(), 'url' => '' );
	} elseif ( is_singular( 'team' ) ) {
		$items[] = array( 'label' => __( 'Teams', 'strikehub' ), 'url' => get_post_type_archive_link( 'team' ) );
		$items[] = array( 'label' => get_the_title(), 'url' => '' );
	} elseif ( is_singular( 'event' ) ) {
		$items[] = array( 'label' => __( 'Events', 'strikehub' ), 'url' => get_post_type_archive_link( 'event' ) );
		$items[] = array( 'label' => get_the_title(), 'url' => '' );
	} elseif ( is_singular( 'cs2_match' ) ) {
		$items[] = array( 'label' => __( 'Matches', 'strikehub' ), 'url' => get_post_type_archive_link( 'cs2_match' ) );
		$items[] = array( 'label' => get_the_title(), 'url' => '' );
	} elseif ( is_singular() ) {
		$items[] = array( 'label' => __( 'News', 'strikehub' ), 'url' => home_url( '/news/' ) );
		$items[] = array( 'label' => get_the_title(), 'url' => '' );
	} elseif ( is_search() ) {
		$items[] = array(
			/* translators: %s: search query */
			'label' => sprintf( __( 'Search results for &ldquo;%s&rdquo;', 'strikehub' ), get_search_query() ),
			'url'   => '',
		);
	} elseif ( is_archive() ) {
		$items[] = array( 'label' => get_the_archive_title(), 'url' => '' );
	} elseif ( is_404() ) {
		$items[] = array( 'label' => __( 'Page not found', 'strikehub' ), 'url' => '' );
	}

	$json_ld = array(
		'@context'        => 'https://schema.org',
		'@type'           => 'BreadcrumbList',
		'itemListElement' => array(),
	);

	echo '<nav class="breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'strikehub' ) . '"><ol>';
	foreach ( $items as $i => $item ) {
		$position                            = $i + 1;
		$json_ld['itemListElement'][ $i ] = array(
			'@type'    => 'ListItem',
			'position' => $position,
			'name'     => wp_strip_all_tags( $item['label'] ),
		);
		if ( ! empty( $item['url'] ) ) {
			$json_ld['itemListElement'][ $i ]['item'] = esc_url( $item['url'] );
			echo '<li><a href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['label'] ) . '</a></li>';
		} else {
			echo '<li aria-current="page">' . esc_html( $item['label'] ) . '</li>';
		}
	}
	echo '</ol></nav>';

	echo '<script type="application/ld+json">' . wp_json_encode( $json_ld ) . '</script>';
}
