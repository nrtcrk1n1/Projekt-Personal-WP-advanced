<?php
/**
 * Theme Customizer settings.
 *
 * @package StrikeHub
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function strikehub_customize_register( $wp_customize ) {

	$wp_customize->add_panel( 'strikehub_panel', array( 'title' => __( 'StrikeHub Options', 'strikehub' ) ) );

	/* Colours ------------------------------------------------------- */
	$wp_customize->add_section( 'strikehub_colors', array( 'title' => __( 'Colors', 'strikehub' ), 'panel' => 'strikehub_panel' ) );

	$colors = array(
		'accent_color'  => array( '#de9b35', __( 'Accent Color (CS Orange)', 'strikehub' ) ),
		'accent2_color' => array( '#5885a2', __( 'Secondary Accent (CT Blue)', 'strikehub' ) ),
		'success_color' => array( '#4caf7d', __( 'Success Color', 'strikehub' ) ),
		'danger_color'  => array( '#c1432f', __( 'Danger Color', 'strikehub' ) ),
		'live_color'    => array( '#ff4655', __( 'Live Color', 'strikehub' ) ),
	);
	foreach ( $colors as $id => $conf ) {
		$wp_customize->add_setting( $id, array( 'default' => $conf[0], 'sanitize_callback' => 'sanitize_hex_color' ) );
		$wp_customize->add_control(
			new WP_Customize_Color_Control( $wp_customize, $id, array( 'label' => $conf[1], 'section' => 'strikehub_colors', 'settings' => $id ) )
		);
	}

	$wp_customize->add_setting( 'color_mode', array( 'default' => 'dark', 'sanitize_callback' => 'strikehub_sanitize_select' ) );
	$wp_customize->add_control(
		'color_mode',
		array(
			'type'    => 'radio',
			'section' => 'strikehub_colors',
			'label'   => __( 'Color Mode', 'strikehub' ),
			'choices' => array( 'dark' => __( 'Dark', 'strikehub' ), 'light' => __( 'Light', 'strikehub' ) ),
		)
	);

	/* Logo / favicon (native WP controls) ---------------------------- */
	add_theme_support( 'custom-logo', array( 'height' => 60, 'width' => 240, 'flex-height' => true, 'flex-width' => true ) );
	add_theme_support( 'site-icon' ); // Powers native favicon control at Customizer > Site Identity.

	/* Header / ticker ------------------------------------------------ */
	$wp_customize->add_section( 'strikehub_header', array( 'title' => __( 'Header & Ticker', 'strikehub' ), 'panel' => 'strikehub_panel' ) );

	$wp_customize->add_setting( 'enable_ticker', array( 'default' => true, 'sanitize_callback' => 'wp_validate_boolean' ) );
	$wp_customize->add_control( 'enable_ticker', array( 'type' => 'checkbox', 'section' => 'strikehub_header', 'label' => __( 'Enable breaking-news ticker', 'strikehub' ) ) );

	$wp_customize->add_setting( 'enable_secondary_nav', array( 'default' => true, 'sanitize_callback' => 'wp_validate_boolean' ) );
	$wp_customize->add_control( 'enable_secondary_nav', array( 'type' => 'checkbox', 'section' => 'strikehub_header', 'label' => __( 'Enable secondary navigation bar', 'strikehub' ) ) );

	/* Homepage section toggles ---------------------------------------- */
	$wp_customize->add_section( 'strikehub_homepage', array( 'title' => __( 'Homepage Sections', 'strikehub' ), 'panel' => 'strikehub_panel' ) );

	$sections = array(
		'show_slider'       => __( 'Featured News Slider', 'strikehub' ),
		'show_latest_news'  => __( 'Latest News', 'strikehub' ),
		'show_matches'      => __( 'Match Center', 'strikehub' ),
		'show_players'      => __( 'Players of the Day', 'strikehub' ),
		'show_fire'         => __( 'Teams on Fire', 'strikehub' ),
		'show_transfers'    => __( 'Latest Transfers', 'strikehub' ),
		'show_popular'      => __( 'Popular Articles', 'strikehub' ),
	);
	foreach ( $sections as $id => $label ) {
		$wp_customize->add_setting( $id, array( 'default' => true, 'sanitize_callback' => 'wp_validate_boolean' ) );
		$wp_customize->add_control( $id, array( 'type' => 'checkbox', 'section' => 'strikehub_homepage', 'label' => $label ) );
	}

	/* Footer / social -------------------------------------------------- */
	$wp_customize->add_section( 'strikehub_footer', array( 'title' => __( 'Footer & Social', 'strikehub' ), 'panel' => 'strikehub_panel' ) );

	$wp_customize->add_setting( 'footer_text', array( 'default' => '', 'sanitize_callback' => 'wp_kses_post' ) );
	$wp_customize->add_control( 'footer_text', array( 'type' => 'textarea', 'section' => 'strikehub_footer', 'label' => __( 'Footer Text', 'strikehub' ) ) );

	$socials = array( 'discord_url' => 'Discord', 'twitter_url' => 'Twitter / X', 'youtube_url' => 'YouTube', 'twitch_url' => 'Twitch' );
	foreach ( $socials as $id => $label ) {
		$wp_customize->add_setting( $id, array( 'default' => '', 'sanitize_callback' => 'esc_url_raw' ) );
		$wp_customize->add_control( $id, array( 'type' => 'url', 'section' => 'strikehub_footer', 'label' => $label ) );
	}
}
add_action( 'customize_register', 'strikehub_customize_register' );

function strikehub_sanitize_select( $input ) {
	return in_array( $input, array( 'dark', 'light' ), true ) ? $input : 'dark';
}

/**
 * Print Customizer colours as CSS custom properties, overriding the
 * defaults from main.css.
 */
function strikehub_customizer_css() {
	$accent  = sanitize_hex_color( get_theme_mod( 'accent_color', '#de9b35' ) );
	$accent2 = sanitize_hex_color( get_theme_mod( 'accent2_color', '#5885a2' ) );
	$success = sanitize_hex_color( get_theme_mod( 'success_color', '#4caf7d' ) );
	$danger  = sanitize_hex_color( get_theme_mod( 'danger_color', '#c1432f' ) );
	$live    = sanitize_hex_color( get_theme_mod( 'live_color', '#ff4655' ) );
	$mode    = get_theme_mod( 'color_mode', 'dark' );
	?>
	<style id="strikehub-customizer-css">
		:root {
			--accent: <?php echo esc_html( $accent ); ?>;
			--accent-2: <?php echo esc_html( $accent2 ); ?>;
			--ct-blue: <?php echo esc_html( $accent2 ); ?>;
			--success: <?php echo esc_html( $success ); ?>;
			--danger: <?php echo esc_html( $danger ); ?>;
			--live: <?php echo esc_html( $live ); ?>;
		}
	</style>
	<?php
	if ( 'light' === $mode ) {
		echo '<script>document.documentElement.setAttribute("data-theme","light");</script>';
	}
}
add_action( 'wp_head', 'strikehub_customizer_css' );