<?php
/**
 * Custom Post Types: player, team, event, cs2_match.
 *
 * @package StrikeHub
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function strikehub_register_post_types() {

	register_post_type(
		'player',
		array(
			'labels'             => array(
				'name'          => __( 'Players', 'strikehub' ),
				'singular_name' => __( 'Player', 'strikehub' ),
				'add_new_item'  => __( 'Add New Player', 'strikehub' ),
				'edit_item'     => __( 'Edit Player', 'strikehub' ),
				'search_items'  => __( 'Search Players', 'strikehub' ),
				'not_found'     => __( 'No players found', 'strikehub' ),
			),
			'public'             => true,
			'has_archive'        => true,
			'rewrite'            => array( 'slug' => 'players' ),
			'menu_icon'          => 'dashicons-groups',
			'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt', 'revisions' ),
			'show_in_rest'       => true,
			'menu_position'      => 20,
		)
	);

	register_post_type(
		'team',
		array(
			'labels'             => array(
				'name'          => __( 'Teams', 'strikehub' ),
				'singular_name' => __( 'Team', 'strikehub' ),
				'add_new_item'  => __( 'Add New Team', 'strikehub' ),
				'edit_item'     => __( 'Edit Team', 'strikehub' ),
				'search_items'  => __( 'Search Teams', 'strikehub' ),
				'not_found'     => __( 'No teams found', 'strikehub' ),
			),
			'public'             => true,
			'has_archive'        => true,
			'rewrite'            => array( 'slug' => 'teams' ),
			'menu_icon'          => 'dashicons-shield',
			'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt', 'revisions' ),
			'show_in_rest'       => true,
			'menu_position'      => 21,
		)
	);

	register_post_type(
		'event',
		array(
			'labels'             => array(
				'name'          => __( 'Events', 'strikehub' ),
				'singular_name' => __( 'Event', 'strikehub' ),
				'add_new_item'  => __( 'Add New Event', 'strikehub' ),
				'edit_item'     => __( 'Edit Event', 'strikehub' ),
				'search_items'  => __( 'Search Events', 'strikehub' ),
				'not_found'     => __( 'No events found', 'strikehub' ),
			),
			'public'             => true,
			'has_archive'        => true,
			'rewrite'            => array( 'slug' => 'events' ),
			'menu_icon'          => 'dashicons-awards',
			'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt', 'revisions' ),
			'show_in_rest'       => true,
			'menu_position'      => 22,
		)
	);

	register_post_type(
		'cs2_match',
		array(
			'labels'             => array(
				'name'          => __( 'Matches', 'strikehub' ),
				'singular_name' => __( 'Match', 'strikehub' ),
				'add_new_item'  => __( 'Add New Match', 'strikehub' ),
				'edit_item'     => __( 'Edit Match', 'strikehub' ),
				'search_items'  => __( 'Search Matches', 'strikehub' ),
				'not_found'     => __( 'No matches found', 'strikehub' ),
			),
			'public'             => true,
			'has_archive'        => true,
			'rewrite'            => array( 'slug' => 'matches' ),
			'menu_icon'          => 'dashicons-controls-play',
			'supports'           => array( 'title', 'editor', 'revisions' ),
			'show_in_rest'       => true,
			'menu_position'      => 23,
		)
	);

	register_post_type(
		'transfer',
		array(
			'labels'             => array(
				'name'          => __( 'Transfers', 'strikehub' ),
				'singular_name' => __( 'Transfer', 'strikehub' ),
				'add_new_item'  => __( 'Add New Transfer', 'strikehub' ),
				'edit_item'     => __( 'Edit Transfer', 'strikehub' ),
			),
			'public'             => true,
			'has_archive'        => true,
			'rewrite'            => array( 'slug' => 'transfers' ),
			'menu_icon'          => 'dashicons-randomize',
			'supports'           => array( 'title', 'editor', 'revisions' ),
			'show_in_rest'       => true,
			'menu_position'      => 24,
		)
	);
}
add_action( 'init', 'strikehub_register_post_types' );

/**
 * Flush rewrite rules once on theme activation so CPT archives work
 * immediately without the admin needing to re-save permalinks.
 */
function strikehub_flush_rewrites() {
	strikehub_register_post_types();
	strikehub_register_taxonomies();
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'strikehub_flush_rewrites' );
