<?php
/**
 * Custom WP_Widget classes. Each widget renders through a template part
 * in template-parts/widgets/ so markup stays out of PHP class bodies.
 *
 * @package StrikeHub
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shared base: title field + compact/expanded display mode field.
 */
abstract class StrikeHub_Widget extends WP_Widget {

	protected $template = '';

	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? $instance['title'] : $this->widget_options['description'];
		$mode  = isset( $instance['mode'] ) ? $instance['mode'] : 'expanded';
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'strikehub' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'mode' ) ); ?>"><?php esc_html_e( 'Display:', 'strikehub' ); ?></label>
			<select id="<?php echo esc_attr( $this->get_field_id( 'mode' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'mode' ) ); ?>">
				<option value="expanded" <?php selected( $mode, 'expanded' ); ?>><?php esc_html_e( 'Expanded', 'strikehub' ); ?></option>
				<option value="compact" <?php selected( $mode, 'compact' ); ?>><?php esc_html_e( 'Compact', 'strikehub' ); ?></option>
			</select>
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance          = array();
		$instance['title'] = sanitize_text_field( $new_instance['title'] );
		$instance['mode']  = ( 'compact' === $new_instance['mode'] ) ? 'compact' : 'expanded';
		return $instance;
	}

	protected function render( $args, $instance, $data = array() ) {
		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title']; // phpcs:ignore
		}
		$mode = isset( $instance['mode'] ) ? $instance['mode'] : 'expanded';
		if ( $this->template && locate_template( 'template-parts/widgets/' . $this->template . '.php' ) ) {
			$data['mode'] = $mode;
			get_template_part( 'template-parts/widgets/' . $this->template, null, $data );
		}
		echo $args['after_widget'];
	}
}

class StrikeHub_Top_Teams_Widget extends StrikeHub_Widget {
	protected $template = 'top-teams';
	public function __construct() {
		parent::__construct( 'strikehub_top_teams', __( 'CS2: Top 10 Teams Today', 'strikehub' ), array( 'description' => __( 'Top 10 Teams Today', 'strikehub' ) ) );
	}
	public function widget( $args, $instance ) {
		$this->render( $args, $instance, array( 'teams' => cs2_get_top_teams_today( 10 ) ) );
	}
}

class StrikeHub_Players_Of_Day_Widget extends StrikeHub_Widget {
	protected $template = 'players-of-day';
	public function __construct() {
		parent::__construct( 'strikehub_players_of_day', __( 'CS2: Players of the Day', 'strikehub' ), array( 'description' => __( 'Players of the Day', 'strikehub' ) ) );
	}
	public function widget( $args, $instance ) {
		$this->render( $args, $instance, array( 'players' => cs2_get_players_of_the_day( 5 ) ) );
	}
}

class StrikeHub_Matches_Today_Widget extends StrikeHub_Widget {
	protected $template = 'matches-today';
	public function __construct() {
		parent::__construct( 'strikehub_matches_today', __( 'CS2: Matches Today', 'strikehub' ), array( 'description' => __( 'Matches Today', 'strikehub' ) ) );
	}
	public function widget( $args, $instance ) {
		$this->render( $args, $instance, array( 'matches' => strikehub_get_matches_today( 10 )->posts ) );
	}
}

class StrikeHub_Upcoming_Matches_Widget extends StrikeHub_Widget {
	protected $template = 'matches-today';
	public function __construct() {
		parent::__construct( 'strikehub_upcoming_matches', __( 'CS2: Upcoming Matches', 'strikehub' ), array( 'description' => __( 'Upcoming Matches', 'strikehub' ) ) );
	}
	public function widget( $args, $instance ) {
		$this->render( $args, $instance, array( 'matches' => strikehub_get_matches_by_status( 'upcoming', 8 )->posts ) );
	}
}

class StrikeHub_Recent_Results_Widget extends StrikeHub_Widget {
	protected $template = 'matches-today';
	public function __construct() {
		parent::__construct( 'strikehub_recent_results', __( 'CS2: Recent Results', 'strikehub' ), array( 'description' => __( 'Recent Results', 'strikehub' ) ) );
	}
	public function widget( $args, $instance ) {
		$this->render( $args, $instance, array( 'matches' => strikehub_get_matches_by_status( 'final', 8 )->posts ) );
	}
}

class StrikeHub_World_Ranking_Widget extends StrikeHub_Widget {
	protected $template = 'world-ranking';
	public function __construct() {
		parent::__construct( 'strikehub_world_ranking', __( 'CS2: World Ranking', 'strikehub' ), array( 'description' => __( 'World Ranking', 'strikehub' ) ) );
	}
	public function widget( $args, $instance ) {
		$this->render( $args, $instance, array( 'teams' => strikehub_get_teams_by_ranking( 10 )->posts ) );
	}
}

class StrikeHub_Teams_On_Fire_Widget extends StrikeHub_Widget {
	protected $template = 'teams-on-fire';
	public function __construct() {
		parent::__construct( 'strikehub_teams_on_fire', __( 'CS2: Teams on Fire', 'strikehub' ), array( 'description' => __( 'Teams on Fire', 'strikehub' ) ) );
	}
	public function widget( $args, $instance ) {
		$this->render( $args, $instance, array( 'teams' => cs2_get_teams_on_fire( 5 ) ) );
	}
}

class StrikeHub_Rising_Teams_Widget extends StrikeHub_Widget {
	protected $template = 'rising-teams';
	public function __construct() {
		parent::__construct( 'strikehub_rising_teams', __( 'CS2: Rising Teams', 'strikehub' ), array( 'description' => __( 'Rising Teams', 'strikehub' ) ) );
	}
	public function widget( $args, $instance ) {
		$this->render( $args, $instance, array( 'teams' => cs2_get_rising_teams( 5 ) ) );
	}
}

class StrikeHub_Trending_Widget extends StrikeHub_Widget {
	protected $template = 'trending';
	public function __construct() {
		parent::__construct( 'strikehub_trending', __( 'CS2: Trending Today', 'strikehub' ), array( 'description' => __( 'Trending Today', 'strikehub' ) ) );
	}
	public function widget( $args, $instance ) {
		$this->render( $args, $instance, array( 'articles' => cs2_get_trending_articles( 5 ) ) );
	}
}

class StrikeHub_Latest_News_Widget extends StrikeHub_Widget {
	protected $template = 'latest-news';
	public function __construct() {
		parent::__construct( 'strikehub_latest_news', __( 'CS2: Latest News', 'strikehub' ), array( 'description' => __( 'Latest News', 'strikehub' ) ) );
	}
	public function widget( $args, $instance ) {
		$this->render( $args, $instance, array( 'posts' => strikehub_get_news( array( 'posts_per_page' => 6 ) )->posts ) );
	}
}

class StrikeHub_Form_Guide_Widget extends StrikeHub_Widget {
	protected $template = 'form-guide';
	public function __construct() {
		parent::__construct( 'strikehub_form_guide', __( 'CS2: Team Form Guide', 'strikehub' ), array( 'description' => __( 'Team Form Guide', 'strikehub' ) ) );
	}
	public function widget( $args, $instance ) {
		$teams = strikehub_get_teams_by_ranking( 8 )->posts;
		$rows  = array();
		foreach ( $teams as $team ) {
			$rows[] = array(
				'team_id' => $team->ID,
				'form'    => strikehub_get_team_form( $team->ID, 5 ),
			);
		}
		$this->render( $args, $instance, array( 'rows' => $rows ) );
	}
}

function strikehub_register_widgets() {
	register_widget( 'StrikeHub_Top_Teams_Widget' );
	register_widget( 'StrikeHub_Players_Of_Day_Widget' );
	register_widget( 'StrikeHub_Matches_Today_Widget' );
	register_widget( 'StrikeHub_Upcoming_Matches_Widget' );
	register_widget( 'StrikeHub_Recent_Results_Widget' );
	register_widget( 'StrikeHub_World_Ranking_Widget' );
	register_widget( 'StrikeHub_Teams_On_Fire_Widget' );
	register_widget( 'StrikeHub_Rising_Teams_Widget' );
	register_widget( 'StrikeHub_Trending_Widget' );
	register_widget( 'StrikeHub_Latest_News_Widget' );
	register_widget( 'StrikeHub_Form_Guide_Widget' );
}
add_action( 'widgets_init', 'strikehub_register_widgets' );
