<?php
/**
 * Reusable helper functions.
 *
 * @package StrikeHub
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Estimated reading time for a post, in whole minutes (minimum 1).
 */
function strikehub_reading_time( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$content = get_post_field( 'post_content', $post_id );
	$words   = str_word_count( wp_strip_all_tags( $content ) );
	$minutes = max( 1, (int) round( $words / 200 ) );
	/* translators: %d: number of minutes */
	return sprintf( _n( '%d min read', '%d min read', $minutes, 'strikehub' ), $minutes );
}

/**
 * Track and return a simple view count stored in post meta.
 * Increment is skipped for logged-in editors to avoid inflating counts
 * while writing/reviewing content, and is rate-limited per visitor via a
 * short-lived transient keyed on IP + post to avoid double counting.
 */
function strikehub_track_view( $post_id ) {
	if ( is_admin() || current_user_can( 'edit_posts' ) ) {
		return;
	}

	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
	$key = 'strikehub_seen_' . $post_id . '_' . md5( $ip );

	if ( get_transient( $key ) ) {
		return;
	}
	set_transient( $key, 1, 30 * MINUTE_IN_SECONDS );

	$count = (int) get_post_meta( $post_id, '_strikehub_views', true );
	update_post_meta( $post_id, '_strikehub_views', $count + 1 );
}

function strikehub_get_views( $post_id ) {
	return (int) get_post_meta( $post_id, '_strikehub_views', true );
}

/**
 * Human "time ago" string, e.g. "35 min ago", "2 hours ago".
 */
function strikehub_time_ago( $timestamp ) {
	$diff = time() - $timestamp;
	if ( $diff < MINUTE_IN_SECONDS ) {
		return __( 'just now', 'strikehub' );
	}
	/* translators: %s: human-readable time difference */
	return sprintf( __( '%s ago', 'strikehub' ), human_time_diff( $timestamp, time() ) );
}

/**
 * Safe wrapper around get_post_meta() with a default fallback.
 */
function strikehub_meta( $post_id, $key, $default = '' ) {
	$value = get_post_meta( $post_id, $key, true );
	return ( '' === $value || null === $value ) ? $default : $value;
}

/**
 * Render a match/team/event status as a colour-coded badge.
 * Uses text + colour (never colour alone) for accessibility.
 */
function strikehub_status_badge( $status ) {
	$status = strtolower( (string) $status );
	$map    = array(
		'upcoming'  => __( 'Upcoming', 'strikehub' ),
		'live'      => __( 'Live', 'strikehub' ),
		'final'     => __( 'Final', 'strikehub' ),
		'postponed' => __( 'Postponed', 'strikehub' ),
		'cancelled' => __( 'Cancelled', 'strikehub' ),
	);
	$label = isset( $map[ $status ] ) ? $map[ $status ] : ucfirst( $status );
	return '<span class="status-badge status-' . esc_attr( $status ) . '">' . esc_html( $label ) . '</span>';
}

/**
 * Renders a "no data available" placeholder. Used everywhere a widget or
 * template has nothing real to show, instead of ever inventing numbers.
 */
function strikehub_no_data( $message = '' ) {
	$message = $message ? $message : __( 'No data available', 'strikehub' );
	echo '<p class="no-data">' . esc_html( $message ) . '</p>';
}

/**
 * Country flag emoji from a 2-letter ISO code stored in post meta.
 * Falls back to nothing (no fake flag) if the code is missing/invalid.
 */
function strikehub_flag( $iso2 ) {
	$iso2 = strtoupper( trim( (string) $iso2 ) );
	if ( 2 !== strlen( $iso2 ) || ! ctype_alpha( $iso2 ) ) {
		return '';
	}
	$flag = '';
	foreach ( str_split( $iso2 ) as $char ) {
		$flag .= mb_chr( 127397 + ord( $char ), 'UTF-8' );
	}
	return $flag;
}

/**
 * Ranking movement indicator: ▲ +n / ▼ -n / — / NEW.
 * $diff is (previous_position - current_position); positive = improved.
 */
function strikehub_movement_badge( $diff, $is_new = false ) {
	if ( $is_new ) {
		return '<span class="movement movement-new">' . esc_html__( 'NEW', 'strikehub' ) . '</span>';
	}
	$diff = (int) $diff;
	if ( 0 === $diff ) {
		return '<span class="movement movement-flat" aria-label="' . esc_attr__( 'No change', 'strikehub' ) . '">&mdash;</span>';
	}
	if ( $diff > 0 ) {
		return '<span class="movement movement-up">&#9650; ' . esc_html( $diff ) . '</span>';
	}
	return '<span class="movement movement-down">&#9660; ' . esc_html( abs( $diff ) ) . '</span>';
}
