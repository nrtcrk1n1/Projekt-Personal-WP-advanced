<?php
/**
 * Optional shortcodes so editors can drop widgets into post content.
 * These reuse the exact same template parts and data functions as the
 * sidebar widgets, so output is always consistent.
 *
 * @package StrikeHub
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function strikehub_shortcode_wrap( $template, $data, $mode = 'expanded' ) {
	if ( ! locate_template( 'template-parts/widgets/' . $template . '.php' ) ) {
		return '';
	}
	$data['mode'] = $mode;
	ob_start();
	get_template_part( 'template-parts/widgets/' . $template, null, $data );
	return ob_get_clean();
}

add_shortcode(
	'cs2_top_teams',
	function ( $atts ) {
		$atts = shortcode_atts( array( 'limit' => 10, 'mode' => 'expanded' ), $atts, 'cs2_top_teams' );
		return strikehub_shortcode_wrap( 'top-teams', array( 'teams' => cs2_get_top_teams_today( absint( $atts['limit'] ) ) ), $atts['mode'] );
	}
);

add_shortcode(
	'cs2_players_of_day',
	function ( $atts ) {
		$atts = shortcode_atts( array( 'limit' => 5, 'mode' => 'expanded' ), $atts, 'cs2_players_of_day' );
		return strikehub_shortcode_wrap( 'players-of-day', array( 'players' => cs2_get_players_of_the_day( absint( $atts['limit'] ) ) ), $atts['mode'] );
	}
);

add_shortcode(
	'cs2_matches_today',
	function ( $atts ) {
		$atts = shortcode_atts( array( 'mode' => 'expanded' ), $atts, 'cs2_matches_today' );
		return strikehub_shortcode_wrap( 'matches-today', array( 'matches' => strikehub_get_matches_today( 20 )->posts ), $atts['mode'] );
	}
);

add_shortcode(
	'cs2_trending',
	function ( $atts ) {
		$atts = shortcode_atts( array( 'limit' => 5, 'mode' => 'expanded' ), $atts, 'cs2_trending' );
		return strikehub_shortcode_wrap( 'trending', array( 'articles' => cs2_get_trending_articles( absint( $atts['limit'] ) ) ), $atts['mode'] );
	}
);

add_shortcode(
	'cs2_team_form',
	function ( $atts ) {
		$atts = shortcode_atts( array( 'team' => 0, 'count' => 5 ), $atts, 'cs2_team_form' );
		$team_id = absint( $atts['team'] );
		if ( ! $team_id ) {
			return '';
		}
		return strikehub_shortcode_wrap(
			'form-guide',
			array( 'rows' => array( array( 'team_id' => $team_id, 'form' => strikehub_get_team_form( $team_id, absint( $atts['count'] ) ) ) ) )
		);
	}
);
