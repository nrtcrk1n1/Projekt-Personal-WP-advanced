<?php
/**
 * Taxonomies used for filtering players, teams, matches and news.
 *
 * @package StrikeHub
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function strikehub_register_taxonomies() {

	register_taxonomy(
		'player_role',
		array( 'player' ),
		array(
			'labels'       => array(
				'name'          => __( 'Roles', 'strikehub' ),
				'singular_name' => __( 'Role', 'strikehub' ),
			),
			'hierarchical' => false,
			'public'       => true,
			'show_in_rest' => true,
			'rewrite'      => array( 'slug' => 'role' ),
		)
	);

	register_taxonomy(
		'region',
		array( 'player', 'team' ),
		array(
			'labels'       => array(
				'name'          => __( 'Regions', 'strikehub' ),
				'singular_name' => __( 'Region', 'strikehub' ),
			),
			'hierarchical' => true,
			'public'       => true,
			'show_in_rest' => true,
			'rewrite'      => array( 'slug' => 'region' ),
		)
	);

	register_taxonomy(
		'match_status',
		array( 'cs2_match' ),
		array(
			'labels'       => array(
				'name'          => __( 'Match Status', 'strikehub' ),
				'singular_name' => __( 'Status', 'strikehub' ),
			),
			'hierarchical' => false,
			'public'       => true,
			'show_in_rest' => true,
			'rewrite'      => array( 'slug' => 'match-status' ),
		)
	);

	register_taxonomy(
		'tournament_type',
		array( 'event' ),
		array(
			'labels'       => array(
				'name'          => __( 'Tournament Types', 'strikehub' ),
				'singular_name' => __( 'Tournament Type', 'strikehub' ),
			),
			'hierarchical' => true,
			'public'       => true,
			'show_in_rest' => true,
			'rewrite'      => array( 'slug' => 'tournament-type' ),
		)
	);

	// Reuse standard post categories for news classification (Breaking,
	// Editorials, Interviews, Transfers, Tournament News, Match Reports,
	// Industry News). Editors create these as normal categories - no
	// separate taxonomy needed, which keeps native WP search/archives working.
	register_taxonomy_for_object_type( 'category', 'post' );
	register_taxonomy_for_object_type( 'post_tag', 'post' );
}
add_action( 'init', 'strikehub_register_taxonomies' );
