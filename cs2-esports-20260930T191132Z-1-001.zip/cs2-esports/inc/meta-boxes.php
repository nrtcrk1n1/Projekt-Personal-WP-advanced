<?php
/**
 * Admin meta boxes for custom post types.
 *
 * All fields are saved as post meta (no custom DB tables) and every save
 * routine verifies a nonce, checks user capability, and sanitizes input.
 *
 * @package StrikeHub
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* -------------------------------------------------------------------- */
/* Field schema per post type. Centralised so render + save stay in sync */
/* -------------------------------------------------------------------- */

function strikehub_field_schema( $post_type ) {
	switch ( $post_type ) {

		case 'player':
			return array(
				'nickname'       => array( 'label' => __( 'Nickname', 'strikehub' ), 'type' => 'text' ),
				'real_name'      => array( 'label' => __( 'Real Name', 'strikehub' ), 'type' => 'text' ),
				'country'        => array( 'label' => __( 'Country (ISO-2, e.g. RU)', 'strikehub' ), 'type' => 'text' ),
				'dob'            => array( 'label' => __( 'Date of Birth', 'strikehub' ), 'type' => 'date' ),
				'team_id'        => array( 'label' => __( 'Current Team', 'strikehub' ), 'type' => 'post_select', 'post_type' => 'team' ),
				'weapon'         => array( 'label' => __( 'Primary Weapon', 'strikehub' ), 'type' => 'text' ),
				'social_twitter' => array( 'label' => __( 'Twitter/X URL', 'strikehub' ), 'type' => 'url' ),
				'social_twitch'  => array( 'label' => __( 'Twitch URL', 'strikehub' ), 'type' => 'url' ),
				'rating'         => array( 'label' => __( 'Rating', 'strikehub' ), 'type' => 'number', 'step' => '0.01' ),
				'kd'             => array( 'label' => __( 'K/D', 'strikehub' ), 'type' => 'number', 'step' => '0.01' ),
				'adr'            => array( 'label' => __( 'ADR', 'strikehub' ), 'type' => 'number', 'step' => '0.1' ),
				'kast'           => array( 'label' => __( 'KAST %', 'strikehub' ), 'type' => 'number', 'step' => '0.1' ),
				'hs_pct'         => array( 'label' => __( 'Headshot %', 'strikehub' ), 'type' => 'number', 'step' => '0.1' ),
				'maps_played'    => array( 'label' => __( 'Maps Played', 'strikehub' ), 'type' => 'number' ),
				'rounds_played'  => array( 'label' => __( 'Rounds Played', 'strikehub' ), 'type' => 'number' ),
				'total_kills'    => array( 'label' => __( 'Total Kills', 'strikehub' ), 'type' => 'number' ),
				'total_deaths'   => array( 'label' => __( 'Total Deaths', 'strikehub' ), 'type' => 'number' ),
				'clutches'       => array( 'label' => __( 'Clutches Won', 'strikehub' ), 'type' => 'number' ),
				'aces'           => array( 'label' => __( 'Aces', 'strikehub' ), 'type' => 'number' ),
				'mvps'           => array( 'label' => __( 'MVPs', 'strikehub' ), 'type' => 'number' ),
				'match_wins'     => array( 'label' => __( 'Match Wins', 'strikehub' ), 'type' => 'number' ),
			);

		case 'team':
			return array(
				'country'        => array( 'label' => __( 'Country (ISO-2)', 'strikehub' ), 'type' => 'text' ),
				'coach'          => array( 'label' => __( 'Coach', 'strikehub' ), 'type' => 'text' ),
				'ranking'        => array( 'label' => __( 'World Ranking Position', 'strikehub' ), 'type' => 'number' ),
				'ranking_points' => array( 'label' => __( 'Ranking Points', 'strikehub' ), 'type' => 'number' ),
				'wins'           => array( 'label' => __( 'Wins', 'strikehub' ), 'type' => 'number' ),
				'losses'         => array( 'label' => __( 'Losses', 'strikehub' ), 'type' => 'number' ),
				'win_streak'     => array( 'label' => __( 'Current Win Streak', 'strikehub' ), 'type' => 'number' ),
				'map_wins'       => array( 'label' => __( 'Map Wins', 'strikehub' ), 'type' => 'number' ),
				'map_losses'     => array( 'label' => __( 'Map Losses', 'strikehub' ), 'type' => 'number' ),
				'last_tournament_result' => array(
					'label'   => __( 'Last Tournament Result', 'strikehub' ),
					'type'    => 'select',
					'options' => array(
						''          => __( '— None —', 'strikehub' ),
						'win'       => __( 'Tournament Win', 'strikehub' ),
						'final'     => __( 'Final', 'strikehub' ),
						'semifinal' => __( 'Semifinal', 'strikehub' ),
					),
				),
			);

		case 'cs2_match':
			return array(
				'team1_id'   => array( 'label' => __( 'Team 1', 'strikehub' ), 'type' => 'post_select', 'post_type' => 'team' ),
				'team2_id'   => array( 'label' => __( 'Team 2', 'strikehub' ), 'type' => 'post_select', 'post_type' => 'team' ),
				'event_id'   => array( 'label' => __( 'Event', 'strikehub' ), 'type' => 'post_select', 'post_type' => 'event' ),
				'match_date' => array( 'label' => __( 'Date', 'strikehub' ), 'type' => 'date' ),
				'match_time' => array( 'label' => __( 'Time', 'strikehub' ), 'type' => 'time' ),
				'format'     => array(
					'label'   => __( 'Format', 'strikehub' ),
					'type'    => 'select',
					'options' => array( 'bo1' => 'BO1', 'bo3' => 'BO3', 'bo5' => 'BO5' ),
				),
				'status'     => array(
					'label'   => __( 'Status', 'strikehub' ),
					'type'    => 'select',
					'options' => array(
						'upcoming'  => __( 'Upcoming', 'strikehub' ),
						'live'      => __( 'Live', 'strikehub' ),
						'final'     => __( 'Final', 'strikehub' ),
						'postponed' => __( 'Postponed', 'strikehub' ),
						'cancelled' => __( 'Cancelled', 'strikehub' ),
					),
				),
				'score1'     => array( 'label' => __( 'Team 1 Score', 'strikehub' ), 'type' => 'number' ),
				'score2'     => array( 'label' => __( 'Team 2 Score', 'strikehub' ), 'type' => 'number' ),
				'maps'       => array( 'label' => __( 'Maps (one per line: MapName Score1-Score2)', 'strikehub' ), 'type' => 'textarea' ),
			);

		case 'event':
			return array(
				'organizer'   => array( 'label' => __( 'Organizer', 'strikehub' ), 'type' => 'text' ),
				'location'    => array( 'label' => __( 'Location', 'strikehub' ), 'type' => 'text' ),
				'prize_pool'  => array( 'label' => __( 'Prize Pool', 'strikehub' ), 'type' => 'text' ),
				'start_date'  => array( 'label' => __( 'Start Date', 'strikehub' ), 'type' => 'date' ),
				'end_date'    => array( 'label' => __( 'End Date', 'strikehub' ), 'type' => 'date' ),
				'status'      => array(
					'label'   => __( 'Status', 'strikehub' ),
					'type'    => 'select',
					'options' => array(
						'upcoming' => __( 'Upcoming', 'strikehub' ),
						'ongoing'  => __( 'Ongoing', 'strikehub' ),
						'finished' => __( 'Finished', 'strikehub' ),
					),
				),
			);

		case 'transfer':
			return array(
				'player_id'       => array( 'label' => __( 'Player', 'strikehub' ), 'type' => 'post_select', 'post_type' => 'player' ),
				'from_team_id'    => array( 'label' => __( 'From Team', 'strikehub' ), 'type' => 'post_select', 'post_type' => 'team' ),
				'to_team_id'      => array( 'label' => __( 'To Team', 'strikehub' ), 'type' => 'post_select', 'post_type' => 'team' ),
				'transfer_date'   => array( 'label' => __( 'Date', 'strikehub' ), 'type' => 'date' ),
				'transfer_type'   => array( 'label' => __( 'Transfer Type', 'strikehub' ), 'type' => 'text' ),
			);

		default:
			return array();
	}
}

/* -------------------------------------------------------------------- */
/* Register + render                                                     */
/* -------------------------------------------------------------------- */

function strikehub_add_meta_boxes() {
	$boxes = array(
		'player'    => __( 'Player Details', 'strikehub' ),
		'team'      => __( 'Team Details', 'strikehub' ),
		'cs2_match' => __( 'Match Details', 'strikehub' ),
		'event'     => __( 'Event Details', 'strikehub' ),
		'transfer'  => __( 'Transfer Details', 'strikehub' ),
	);
	foreach ( $boxes as $post_type => $title ) {
		add_meta_box(
			'strikehub_' . $post_type . '_details',
			$title,
			'strikehub_render_meta_box',
			$post_type,
			'normal',
			'high'
		);
	}
}
add_action( 'add_meta_boxes', 'strikehub_add_meta_boxes' );

function strikehub_render_meta_box( $post ) {
	$schema = strikehub_field_schema( $post->post_type );
	wp_nonce_field( 'strikehub_save_meta', 'strikehub_meta_nonce' );
	echo '<table class="form-table strikehub-meta-table">';
	foreach ( $schema as $key => $field ) {
		$value = get_post_meta( $post->ID, '_' . $key, true );
		echo '<tr><th><label for="strikehub_' . esc_attr( $key ) . '">' . esc_html( $field['label'] ) . '</label></th><td>';
		strikehub_render_field( $key, $field, $value );
		echo '</td></tr>';
	}
	echo '</table>';
}

function strikehub_render_field( $key, $field, $value ) {
	$id   = 'strikehub_' . $key;
	$name = 'strikehub_meta[' . $key . ']';

	switch ( $field['type'] ) {

		case 'textarea':
			echo '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" rows="4" class="widefat">' . esc_textarea( $value ) . '</textarea>';
			break;

		case 'select':
			echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '">';
			foreach ( $field['options'] as $opt_value => $opt_label ) {
				printf(
					'<option value="%s" %s>%s</option>',
					esc_attr( $opt_value ),
					selected( $value, $opt_value, false ),
					esc_html( $opt_label )
				);
			}
			echo '</select>';
			break;

		case 'post_select':
			$posts = get_posts(
				array(
					'post_type'      => $field['post_type'],
					'posts_per_page' => -1,
					'orderby'        => 'title',
					'order'          => 'ASC',
				)
			);
			echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '">';
			echo '<option value="">' . esc_html__( '— None —', 'strikehub' ) . '</option>';
			foreach ( $posts as $p ) {
				printf(
					'<option value="%d" %s>%s</option>',
					$p->ID,
					selected( (int) $value, $p->ID, false ),
					esc_html( $p->post_title )
				);
			}
			echo '</select>';
			break;

		case 'number':
			$step = isset( $field['step'] ) ? $field['step'] : '1';
			echo '<input type="number" step="' . esc_attr( $step ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" class="regular-text">';
			break;

		case 'date':
			echo '<input type="date" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">';
			break;

		case 'time':
			echo '<input type="time" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">';
			break;

		case 'url':
			echo '<input type="url" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" class="regular-text">';
			break;

		case 'text':
		default:
			echo '<input type="text" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" class="regular-text">';
			break;
	}
}

/* -------------------------------------------------------------------- */
/* Save                                                                   */
/* -------------------------------------------------------------------- */

function strikehub_save_meta_boxes( $post_id, $post ) {
	if ( ! isset( $_POST['strikehub_meta_nonce'] ) ||
		! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['strikehub_meta_nonce'] ) ), 'strikehub_save_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	if ( empty( $_POST['strikehub_meta'] ) || ! is_array( $_POST['strikehub_meta'] ) ) {
		return;
	}

	$schema  = strikehub_field_schema( $post->post_type );
	$raw     = wp_unslash( $_POST['strikehub_meta'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

	foreach ( $schema as $key => $field ) {
		if ( ! isset( $raw[ $key ] ) ) {
			continue;
		}
		$value = $raw[ $key ];

		switch ( $field['type'] ) {
			case 'textarea':
				$clean = sanitize_textarea_field( $value );
				break;
			case 'url':
				$clean = esc_url_raw( $value );
				break;
			case 'number':
				$clean = is_numeric( $value ) ? $value : '';
				break;
			case 'post_select':
				$clean = absint( $value );
				break;
			default:
				$clean = sanitize_text_field( $value );
				break;
		}
		update_post_meta( $post_id, '_' . $key, $clean );
	}

	// Whenever a match is saved with a final score, invalidate today's
	// ranking cache so widgets reflect fresh data on next view.
	if ( 'cs2_match' === $post->post_type ) {
		delete_transient( 'cs2_top_teams_' . gmdate( 'Y_m_d' ) );
	}
}
add_action( 'save_post', 'strikehub_save_meta_boxes', 10, 2 );
