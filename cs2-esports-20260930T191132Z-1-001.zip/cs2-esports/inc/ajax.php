<?php
/**
 * AJAX endpoints. Every handler verifies the shared strikehub_ajax_nonce
 * before doing any work, and never trusts raw $_POST/$_GET values.
 *
 * @package StrikeHub
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function strikehub_verify_ajax_nonce() {
	if ( ! isset( $_REQUEST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST['nonce'] ) ), 'strikehub_ajax_nonce' ) ) {
		wp_send_json_error( array( 'message' => __( 'Security check failed.', 'strikehub' ) ), 403 );
	}
}

/**
 * Filter matches by date / event / team / status.
 */
function strikehub_ajax_filter_matches() {
	strikehub_verify_ajax_nonce();

	$args = array(
		'post_type'      => 'cs2_match',
		'posts_per_page' => 20,
		'meta_query'     => array( 'relation' => 'AND' ),
	);

	if ( ! empty( $_POST['status'] ) ) {
		$args['meta_query'][] = array( 'key' => '_status', 'value' => sanitize_text_field( wp_unslash( $_POST['status'] ) ) );
	}
	if ( ! empty( $_POST['date'] ) ) {
		$args['meta_query'][] = array( 'key' => '_match_date', 'value' => sanitize_text_field( wp_unslash( $_POST['date'] ) ) );
	}
	if ( ! empty( $_POST['event'] ) ) {
		$args['meta_query'][] = array( 'key' => '_event_id', 'value' => absint( $_POST['event'] ) );
	}
	if ( ! empty( $_POST['team'] ) ) {
		$team_id                = absint( $_POST['team'] );
		$args['meta_query'][]   = array(
			'relation' => 'OR',
			array( 'key' => '_team1_id', 'value' => $team_id ),
			array( 'key' => '_team2_id', 'value' => $team_id ),
		);
	}

	$query = new WP_Query( $args );

	ob_start();
	if ( $query->have_posts() ) {
		while ( $query->have_posts() ) {
			$query->the_post();
			get_template_part( 'template-parts/match-card' );
		}
		wp_reset_postdata();
	} else {
		strikehub_no_data( __( 'No matches match those filters.', 'strikehub' ) );
	}
	$html = ob_get_clean();

	wp_send_json_success( array( 'html' => $html, 'count' => $query->post_count ) );
}
add_action( 'wp_ajax_strikehub_filter_matches', 'strikehub_ajax_filter_matches' );
add_action( 'wp_ajax_nopriv_strikehub_filter_matches', 'strikehub_ajax_filter_matches' );

/**
 * Filter news by category / team / player / date.
 */
function strikehub_ajax_filter_news() {
	strikehub_verify_ajax_nonce();

	$args = array(
		'post_type'      => 'post',
		'posts_per_page' => 10,
		'paged'          => isset( $_POST['paged'] ) ? absint( $_POST['paged'] ) : 1,
	);

	if ( ! empty( $_POST['category'] ) ) {
		$args['category_name'] = sanitize_title( wp_unslash( $_POST['category'] ) );
	}
	if ( ! empty( $_POST['date'] ) ) {
		$date            = sanitize_text_field( wp_unslash( $_POST['date'] ) );
		$parts           = explode( '-', $date );
		if ( 3 === count( $parts ) ) {
			$args['date_query'] = array(
				array( 'year' => absint( $parts[0] ), 'month' => absint( $parts[1] ), 'day' => absint( $parts[2] ) ),
			);
		}
	}

	$query = new WP_Query( $args );

	ob_start();
	if ( $query->have_posts() ) {
		while ( $query->have_posts() ) {
			$query->the_post();
			get_template_part( 'template-parts/news-card' );
		}
		wp_reset_postdata();
	} else {
		strikehub_no_data( __( 'No articles match those filters.', 'strikehub' ) );
	}
	$html = ob_get_clean();

	wp_send_json_success( array( 'html' => $html, 'max_pages' => $query->max_num_pages ) );
}
add_action( 'wp_ajax_strikehub_filter_news', 'strikehub_ajax_filter_news' );
add_action( 'wp_ajax_nopriv_strikehub_filter_news', 'strikehub_ajax_filter_news' );

/**
 * Filter players by country / team / role.
 */
function strikehub_ajax_filter_players() {
	strikehub_verify_ajax_nonce();

	$args = array(
		'post_type'      => 'player',
		'posts_per_page' => 24,
		'meta_query'     => array( 'relation' => 'AND' ),
		'tax_query'      => array( 'relation' => 'AND' ),
	);

	if ( ! empty( $_POST['country'] ) ) {
		$args['meta_query'][] = array( 'key' => '_country', 'value' => sanitize_text_field( wp_unslash( $_POST['country'] ) ) );
	}
	if ( ! empty( $_POST['team'] ) ) {
		$args['meta_query'][] = array( 'key' => '_team_id', 'value' => absint( $_POST['team'] ) );
	}
	if ( ! empty( $_POST['role'] ) ) {
		$args['tax_query'][] = array( 'taxonomy' => 'player_role', 'field' => 'slug', 'terms' => sanitize_title( wp_unslash( $_POST['role'] ) ) );
	}

	$query = new WP_Query( $args );

	ob_start();
	if ( $query->have_posts() ) {
		while ( $query->have_posts() ) {
			$query->the_post();
			get_template_part( 'template-parts/player-card' );
		}
		wp_reset_postdata();
	} else {
		strikehub_no_data( __( 'No players match those filters.', 'strikehub' ) );
	}
	$html = ob_get_clean();

	wp_send_json_success( array( 'html' => $html ) );
}
add_action( 'wp_ajax_strikehub_filter_players', 'strikehub_ajax_filter_players' );
add_action( 'wp_ajax_nopriv_strikehub_filter_players', 'strikehub_ajax_filter_players' );

/**
 * Refresh the Top 10 Teams Today widget in place, without a page reload.
 */
function strikehub_ajax_refresh_rankings() {
	strikehub_verify_ajax_nonce();

	if ( ! empty( $_POST['force'] ) && current_user_can( 'manage_options' ) ) {
		strikehub_clear_ranking_cache();
	}

	$teams = cs2_get_top_teams_today( 10 );

	ob_start();
	get_template_part( 'template-parts/widgets/top-teams', null, array( 'teams' => $teams, 'mode' => 'expanded' ) );
	$html = ob_get_clean();

	wp_send_json_success( array( 'html' => $html ) );
}
add_action( 'wp_ajax_cs2_refresh_daily_rankings', 'strikehub_ajax_refresh_rankings' );
add_action( 'wp_ajax_nopriv_cs2_refresh_daily_rankings', 'strikehub_ajax_refresh_rankings' );

/**
 * Live search overlay: posts + players + teams + events in one response.
 */
function strikehub_ajax_search() {
	strikehub_verify_ajax_nonce();

	$term = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';
	if ( strlen( $term ) < 2 ) {
		wp_send_json_success( array( 'results' => array() ) );
	}

	$query = new WP_Query(
		array(
			's'              => $term,
			'post_type'      => array( 'post', 'player', 'team', 'event' ),
			'posts_per_page' => 12,
		)
	);

	$results = array();
	foreach ( $query->posts as $post ) {
		$results[] = array(
			'type'  => $post->post_type,
			'title' => get_the_title( $post ),
			'url'   => get_permalink( $post ),
		);
	}

	wp_send_json_success( array( 'results' => $results ) );
}
add_action( 'wp_ajax_strikehub_search', 'strikehub_ajax_search' );
add_action( 'wp_ajax_nopriv_strikehub_search', 'strikehub_ajax_search' );
