<?php
/**
 * Central query helpers. Keeping WP_Query args in one place avoids
 * duplicating the same arrays across templates and widgets.
 *
 * @package StrikeHub
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function strikehub_get_matches( $args = array() ) {
	$defaults = array(
		'post_type'      => 'cs2_match',
		'posts_per_page' => 10,
		'meta_key'       => '_match_date',
		'orderby'        => 'meta_value',
		'order'          => 'ASC',
		'no_found_rows'  => true,
	);
	return new WP_Query( wp_parse_args( $args, $defaults ) );
}

function strikehub_get_matches_by_status( $status, $limit = 10 ) {
	return strikehub_get_matches(
		array(
			'posts_per_page' => $limit,
			'meta_query'     => array(
				array(
					'key'   => '_status',
					'value' => $status,
				),
			),
		)
	);
}

function strikehub_get_matches_today( $limit = 20 ) {
	return strikehub_get_matches(
		array(
			'posts_per_page' => $limit,
			'meta_query'     => array(
				array(
					'key'   => '_match_date',
					'value' => current_time( 'Y-m-d' ),
				),
			),
		)
	);
}

function strikehub_get_news( $args = array() ) {
	$defaults = array(
		'post_type'      => 'post',
		'posts_per_page' => 10,
		'no_found_rows'  => true,
	);
	return new WP_Query( wp_parse_args( $args, $defaults ) );
}

function strikehub_get_popular_news( $limit = 5 ) {
	return strikehub_get_news(
		array(
			'posts_per_page' => $limit,
			'meta_key'       => '_strikehub_views',
			'orderby'        => 'meta_value_num',
			'order'          => 'DESC',
		)
	);
}

function strikehub_get_teams( $args = array() ) {
	$defaults = array(
		'post_type'      => 'team',
		'posts_per_page' => -1,
		'no_found_rows'  => true,
	);
	return new WP_Query( wp_parse_args( $args, $defaults ) );
}

function strikehub_get_teams_by_ranking( $limit = 10 ) {
	return strikehub_get_teams(
		array(
			'posts_per_page' => $limit,
			'meta_key'       => '_ranking',
			'orderby'        => 'meta_value_num',
			'order'          => 'ASC',
			'meta_query'     => array(
				array(
					'key'     => '_ranking',
					'compare' => 'EXISTS',
				),
			),
		)
	);
}

function strikehub_get_players( $args = array() ) {
	$defaults = array(
		'post_type'      => 'player',
		'posts_per_page' => -1,
		'no_found_rows'  => true,
	);
	return new WP_Query( wp_parse_args( $args, $defaults ) );
}

/**
 * Recent matches for a given team (either team1 or team2), most recent first.
 */
function strikehub_get_team_matches( $team_id, $limit = 10 ) {
	$team_id = absint( $team_id );
	return strikehub_get_matches(
		array(
			'posts_per_page' => $limit,
			'orderby'        => 'meta_value',
			'order'          => 'DESC',
			'meta_query'     => array(
				'relation' => 'OR',
				array( 'key' => '_team1_id', 'value' => $team_id ),
				array( 'key' => '_team2_id', 'value' => $team_id ),
			),
		)
	);
}
