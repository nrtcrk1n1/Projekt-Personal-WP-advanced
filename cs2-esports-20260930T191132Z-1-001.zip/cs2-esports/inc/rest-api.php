<?php
/**
 * Public, read-only REST API endpoints. Disabled entirely unless the
 * administrator opts in via Settings > StrikeHub Rankings.
 *
 * @package StrikeHub
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function strikehub_rest_enabled() {
	return (bool) get_option( 'strikehub_enable_rest', false );
}

function strikehub_register_rest_routes() {
	if ( ! strikehub_rest_enabled() ) {
		return;
	}

	register_rest_route(
		'cs2/v1',
		'/teams/top',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => 'strikehub_rest_top_teams',
			'permission_callback' => '__return_true',
			'args'                => array(
				'limit' => array( 'default' => 10, 'sanitize_callback' => 'absint' ),
			),
		)
	);

	register_rest_route(
		'cs2/v1',
		'/players/top',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => 'strikehub_rest_top_players',
			'permission_callback' => '__return_true',
			'args'                => array(
				'limit' => array( 'default' => 5, 'sanitize_callback' => 'absint' ),
			),
		)
	);

	register_rest_route(
		'cs2/v1',
		'/matches/today',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => 'strikehub_rest_matches_today',
			'permission_callback' => '__return_true',
		)
	);

	register_rest_route(
		'cs2/v1',
		'/trending',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => 'strikehub_rest_trending',
			'permission_callback' => '__return_true',
			'args'                => array(
				'limit' => array( 'default' => 5, 'sanitize_callback' => 'absint' ),
			),
		)
	);
}
add_action( 'rest_api_init', 'strikehub_register_rest_routes' );

function strikehub_rest_top_teams( $request ) {
	$limit = $request->get_param( 'limit' );
	$rows  = cs2_get_top_teams_today( $limit );
	$out   = array();
	foreach ( $rows as $row ) {
		$out[] = array(
			'rank'     => $row['position'],
			'team'     => get_the_title( $row['team_id'] ),
			'team_id'  => $row['team_id'],
			'score'    => $row['score'],
			'wins'     => $row['wins'],
			'losses'   => $row['losses'],
			'movement' => $row['movement'],
			'is_new'   => (bool) $row['is_new'],
		);
	}
	return rest_ensure_response( $out );
}

function strikehub_rest_top_players( $request ) {
	$limit = $request->get_param( 'limit' );
	$rows  = cs2_get_players_of_the_day( $limit );
	$out   = array();
	foreach ( $rows as $i => $row ) {
		$out[] = array(
			'rank'      => $i + 1,
			'player'    => get_the_title( $row['player_id'] ),
			'player_id' => $row['player_id'],
			'rating'    => $row['rating'],
		);
	}
	return rest_ensure_response( $out );
}

function strikehub_rest_matches_today( $request ) {
	$matches = strikehub_get_matches_today( 30 )->posts;
	$out     = array();
	foreach ( $matches as $match ) {
		$out[] = array(
			'id'     => $match->ID,
			'team1'  => get_the_title( strikehub_meta( $match->ID, '_team1_id' ) ),
			'team2'  => get_the_title( strikehub_meta( $match->ID, '_team2_id' ) ),
			'time'   => strikehub_meta( $match->ID, '_match_time' ),
			'status' => strikehub_meta( $match->ID, '_status' ),
			'score1' => strikehub_meta( $match->ID, '_score1' ),
			'score2' => strikehub_meta( $match->ID, '_score2' ),
		);
	}
	return rest_ensure_response( $out );
}

function strikehub_rest_trending( $request ) {
	$limit    = $request->get_param( 'limit' );
	$articles = cs2_get_trending_articles( $limit );
	$out      = array();
	foreach ( $articles as $post ) {
		$out[] = array(
			'id'    => $post->ID,
			'title' => get_the_title( $post ),
			'url'   => get_permalink( $post ),
			'views' => strikehub_get_views( $post->ID ),
		);
	}
	return rest_ensure_response( $out );
}
