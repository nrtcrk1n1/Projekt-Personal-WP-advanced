<?php
/**
 * Single match detail page.
 *
 * @package StrikeHub
 */

get_header();

while ( have_posts() ) :
	the_post();
	$id   = get_the_ID();
	$m    = strikehub_get_match_data( $id );
	$maps = strikehub_parse_maps( $m['maps_raw'] );

	$roster1 = $m['team1_id'] ? strikehub_get_players( array( 'meta_key' => '_team_id', 'meta_value' => $m['team1_id'] ) ) : null;
	$roster2 = $m['team2_id'] ? strikehub_get_players( array( 'meta_key' => '_team_id', 'meta_value' => $m['team2_id'] ) ) : null;
	?>
	<div class="layout-single-col">
		<main id="main" class="main-content">
			<?php strikehub_breadcrumbs(); ?>

			<header class="match-header status-<?php echo esc_attr( $m['status'] ); ?>">
				<?php if ( $m['event_name'] ) : ?>
					<p class="match-header-event">
						<?php if ( $m['event_id'] ) : ?>
							<a href="<?php echo esc_url( get_permalink( $m['event_id'] ) ); ?>"><?php echo esc_html( strtoupper( $m['event_name'] ) ); ?></a>
						<?php else : ?>
							<?php echo esc_html( strtoupper( $m['event_name'] ) ); ?>
						<?php endif; ?>
					</p>
				<?php endif; ?>

				<div class="match-header-score">
					<div class="match-header-team">
						<?php if ( $m['team1_id'] && has_post_thumbnail( $m['team1_id'] ) ) : ?>
							<?php echo get_the_post_thumbnail( $m['team1_id'], 'strikehub-logo' ); ?>
						<?php endif; ?>
						<a class="match-header-team-name" href="<?php echo $m['team1_id'] ? esc_url( get_permalink( $m['team1_id'] ) ) : '#'; ?>"><?php echo esc_html( $m['team1_name'] ); ?></a>
					</div>

					<div class="match-header-center">
						<?php if ( 'final' === $m['status'] || 'live' === $m['status'] ) : ?>
							<span class="match-header-score-number"><?php echo esc_html( $m['score1'] ); ?> : <?php echo esc_html( $m['score2'] ); ?></span>
						<?php elseif ( $m['date'] || $m['time'] ) : ?>
							<span class="match-header-datetime" <?php echo ( 'upcoming' === $m['status'] && $m['date'] && $m['time'] ) ? 'data-countdown="' . esc_attr( $m['date'] . 'T' . $m['time'] ) . '"' : ''; ?>>
								<?php echo esc_html( trim( $m['date'] . ' ' . $m['time'] ) ); ?>
							</span>
						<?php endif; ?>
						<?php echo strikehub_status_badge( $m['status'] ); ?>
						<span class="match-header-format"><?php echo esc_html( $m['format'] ); ?></span>
					</div>

					<div class="match-header-team">
						<?php if ( $m['team2_id'] && has_post_thumbnail( $m['team2_id'] ) ) : ?>
							<?php echo get_the_post_thumbnail( $m['team2_id'], 'strikehub-logo' ); ?>
						<?php endif; ?>
						<a class="match-header-team-name" href="<?php echo $m['team2_id'] ? esc_url( get_permalink( $m['team2_id'] ) ) : '#'; ?>"><?php echo esc_html( $m['team2_name'] ); ?></a>
					</div>
				</div>
			</header>

			<section class="maps-section">
				<h2><?php esc_html_e( 'Maps', 'strikehub' ); ?></h2>
				<?php if ( $maps ) : ?>
					<div class="maps-list">
						<?php foreach ( $maps as $i => $map ) : ?>
							<div class="map-row">
								<span class="map-number"><?php /* translators: %d: map number */ printf( esc_html__( 'Map %d', 'strikehub' ), $i + 1 ); ?></span>
								<span class="map-name"><?php echo esc_html( $map['map'] ); ?></span>
								<span class="map-score">
									<?php echo esc_html( $m['team1_name'] ); ?> <?php echo esc_html( $map['score1'] ); ?> &ndash; <?php echo esc_html( $map['score2'] ); ?> <?php echo esc_html( $m['team2_name'] ); ?>
								</span>
							</div>
						<?php endforeach; ?>
					</div>
				<?php else : ?>
					<?php strikehub_no_data(); ?>
				<?php endif; ?>
			</section>

			<section class="lineups-section">
				<h2><?php esc_html_e( 'Lineups', 'strikehub' ); ?></h2>
				<div class="lineups-columns">
					<div class="lineup-col">
						<h3><?php echo esc_html( $m['team1_name'] ); ?></h3>
						<?php if ( $roster1 && $roster1->have_posts() ) : ?>
							<ul class="lineup-list">
								<?php
								while ( $roster1->have_posts() ) :
									$roster1->the_post();
									?>
									<li><a href="<?php the_permalink(); ?>"><?php echo esc_html( strikehub_meta( get_the_ID(), '_nickname', get_the_title() ) ); ?></a></li>
									<?php
								endwhile;
								wp_reset_postdata();
								?>
							</ul>
						<?php else : ?>
							<?php strikehub_no_data(); ?>
						<?php endif; ?>
					</div>
					<div class="lineup-col">
						<h3><?php echo esc_html( $m['team2_name'] ); ?></h3>
						<?php if ( $roster2 && $roster2->have_posts() ) : ?>
							<ul class="lineup-list">
								<?php
								while ( $roster2->have_posts() ) :
									$roster2->the_post();
									?>
									<li><a href="<?php the_permalink(); ?>"><?php echo esc_html( strikehub_meta( get_the_ID(), '_nickname', get_the_title() ) ); ?></a></li>
									<?php
								endwhile;
								wp_reset_postdata();
								?>
							</ul>
						<?php else : ?>
							<?php strikehub_no_data(); ?>
						<?php endif; ?>
					</div>
				</div>
			</section>

			<?php if ( get_the_content() ) : ?>
				<section class="match-report-section">
					<h2><?php esc_html_e( 'Match Report', 'strikehub' ); ?></h2>
					<div class="article-content"><?php the_content(); ?></div>
				</section>
			<?php endif; ?>

			<section class="related-news-section">
				<h2><?php esc_html_e( 'Related News', 'strikehub' ); ?></h2>
				<?php
				$related_terms = array_filter( array( $m['team1_name'], $m['team2_name'] ) );
				$news          = $related_terms ? new WP_Query(
					array(
						's'              => implode( ' ', $related_terms ),
						'posts_per_page' => 3,
						'no_found_rows'  => true,
					)
				) : null;
				if ( $news && $news->have_posts() ) :
					?>
					<div class="news-grid">
						<?php
						while ( $news->have_posts() ) :
							$news->the_post();
							get_template_part( 'template-parts/news-card' );
						endwhile;
						wp_reset_postdata();
						?>
					</div>
					<?php
				else :
					strikehub_no_data();
				endif;
				?>
			</section>
		</main>
	</div>
	<?php
endwhile;

get_footer();
