<?php
/**
 * News card. Expects to run inside The Loop (the_post() already called).
 *
 * @package StrikeHub
 */
$categories = get_the_category();
$cat_name   = $categories ? $categories[0]->name : '';
?>
<article <?php post_class( 'news-card' ); ?>>
	<a class="news-card-media" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
		<?php if ( has_post_thumbnail() ) : ?>
			<?php the_post_thumbnail( 'strikehub-card', array( 'loading' => 'lazy', 'alt' => the_title_attribute( array( 'echo' => false ) ) ) ); ?>
		<?php else : ?>
			<span class="news-card-media-placeholder" aria-hidden="true"></span>
		<?php endif; ?>
	</a>
	<div class="news-card-body">
		<?php if ( $cat_name ) : ?>
			<a class="news-card-category" href="<?php echo esc_url( get_category_link( $categories[0]->term_id ) ); ?>"><?php echo esc_html( $cat_name ); ?></a>
		<?php endif; ?>
		<h3 class="news-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		<p class="news-card-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 18 ) ); ?></p>
		<div class="news-card-meta">
			<span class="news-card-author"><?php the_author(); ?></span>
			<span class="news-card-dot" aria-hidden="true">&middot;</span>
			<span class="news-card-time"><?php echo esc_html( strikehub_time_ago( get_the_time( 'U' ) ) ); ?></span>
			<span class="news-card-dot" aria-hidden="true">&middot;</span>
			<span class="news-card-reading-time"><?php echo esc_html( strikehub_reading_time() ); ?></span>
		</div>
	</div>
</article>
