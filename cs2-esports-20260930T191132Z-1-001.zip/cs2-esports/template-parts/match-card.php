<?php
/**
 * Match card. Expects to run inside The Loop for a cs2_match post.
 *
 * @package StrikeHub
 */
$match = strikehub_get_match_data( get_the_ID() );
$is_live = 'live' === $match['status'];
?>
<article <?php post_class( 'match-card status-' . esc_attr( $match['status'] ) ); ?>>
	<a class="match-card-link" href="<?php the_permalink(); ?>">
		<div class="match-card-top">
			<?php echo strikehub_status_badge( $match['status'] ); ?>
			<?php if ( $match['event_name'] ) : ?>
				<span class="match-card-event"><?php echo esc_html( $match['event_name'] ); ?></span>
			<?php endif; ?>
		</div>

		<div class="match-card-teams">
			<div class="match-card-team">
				<?php if ( $match['team1_id'] && has_post_thumbnail( $match['team1_id'] ) ) : ?>
					<?php echo get_the_post_thumbnail( $match['team1_id'], 'strikehub-thumb', array( 'class' => 'team-logo', 'loading' => 'lazy' ) ); ?>
				<?php endif; ?>
				<span class="team-name"><?php echo esc_html( $match['team1_name'] ); ?></span>
			</div>

			<div class="match-card-center">
				<?php if ( 'final' === $match['status'] || $is_live ) : ?>
					<span class="match-score"><?php echo esc_html( $match['score1'] ); ?> : <?php echo esc_html( $match['score2'] ); ?></span>
				<?php elseif ( $match['time'] ) : ?>
					<span class="match-time"><?php echo esc_html( $match['time'] ); ?></span>
				<?php else : ?>
					<span class="match-time">&mdash;</span>
				<?php endif; ?>
				<span class="match-format"><?php echo esc_html( $match['format'] ); ?></span>
			</div>

			<div class="match-card-team">
				<?php if ( $match['team2_id'] && has_post_thumbnail( $match['team2_id'] ) ) : ?>
					<?php echo get_the_post_thumbnail( $match['team2_id'], 'strikehub-thumb', array( 'class' => 'team-logo', 'loading' => 'lazy' ) ); ?>
				<?php endif; ?>
				<span class="team-name"><?php echo esc_html( $match['team2_name'] ); ?></span>
			</div>
		</div>
	</a>
</article>
