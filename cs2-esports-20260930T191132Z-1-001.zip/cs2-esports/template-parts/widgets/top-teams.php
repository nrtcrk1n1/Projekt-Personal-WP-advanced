<?php
/**
 * Top 10 Teams Today widget/shortcode body.
 *
 * @package StrikeHub
 * @var array $args { teams: array, mode: string }
 */
$teams = isset( $args['teams'] ) ? $args['teams'] : array();
$mode  = isset( $args['mode'] ) ? $args['mode'] : 'expanded';
?>
<div class="cs2-widget cs2-top-teams" data-widget="top-teams">
	<div class="cs2-widget-head">
		<span class="cs2-widget-heading"><?php esc_html_e( 'Top 10 Teams Today', 'strikehub' ); ?></span>
		<button type="button" class="icon-btn refresh-btn" data-action="cs2_refresh_daily_rankings" aria-label="<?php esc_attr_e( 'Refresh rankings', 'strikehub' ); ?>">&#8635;</button>
	</div>

	<?php if ( empty( $teams ) ) : ?>
		<?php strikehub_no_data(); ?>
	<?php else : ?>
		<ol class="cs2-top-teams-list mode-<?php echo esc_attr( $mode ); ?>">
			<?php foreach ( $teams as $row ) : ?>
				<li>
					<span class="ranking-position">#<?php echo esc_html( $row['position'] ); ?></span>
					<?php if ( has_post_thumbnail( $row['team_id'] ) ) : ?>
						<span class="ranking-logo"><?php echo get_the_post_thumbnail( $row['team_id'], 'strikehub-thumb', array( 'loading' => 'lazy' ) ); ?></span>
					<?php endif; ?>
					<a class="ranking-name" href="<?php echo esc_url( get_permalink( $row['team_id'] ) ); ?>"><?php echo esc_html( get_the_title( $row['team_id'] ) ); ?></a>

					<?php if ( 'expanded' === $mode ) : ?>
						<div class="ranking-expanded-meta">
							<span class="ranking-points"><?php echo esc_html( $row['score'] ); ?> <?php esc_html_e( 'pts', 'strikehub' ); ?></span>
							<span class="ranking-record"><?php echo esc_html( $row['wins'] ); ?>W - <?php echo esc_html( $row['losses'] ); ?>L</span>
						</div>
					<?php else : ?>
						<span class="ranking-points"><?php echo esc_html( $row['score'] ); ?></span>
					<?php endif; ?>

					<?php echo strikehub_movement_badge( $row['movement'], ! empty( $row['is_new'] ) ); ?>
				</li>
			<?php endforeach; ?>
		</ol>
		<a class="cs2-widget-footer-link" href="<?php echo esc_url( home_url( '/rankings/' ) ); ?>"><?php esc_html_e( 'View Full Rankings', 'strikehub' ); ?> &rarr;</a>
	<?php endif; ?>
</div>
