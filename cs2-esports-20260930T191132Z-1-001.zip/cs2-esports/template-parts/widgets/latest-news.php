<?php
/**
 * Latest News compact widget/shortcode body.
 *
 * @package StrikeHub
 * @var array $args { posts: WP_Post[] }
 */
$posts = isset( $args['posts'] ) ? $args['posts'] : array();
?>
<div class="cs2-widget cs2-latest-news">
	<?php if ( empty( $posts ) ) : ?>
		<?php strikehub_no_data(); ?>
	<?php else : ?>
		<ul class="cs2-latest-news-list">
			<?php foreach ( $posts as $post ) : ?>
				<li>
					<a href="<?php echo esc_url( get_permalink( $post ) ); ?>" class="latest-news-row">
						<?php if ( has_post_thumbnail( $post ) ) : ?>
							<span class="latest-news-thumb"><?php echo get_the_post_thumbnail( $post, 'strikehub-thumb', array( 'loading' => 'lazy' ) ); ?></span>
						<?php endif; ?>
						<span class="latest-news-text">
							<span class="latest-news-title"><?php echo esc_html( get_the_title( $post ) ); ?></span>
							<span class="latest-news-time"><?php echo esc_html( strikehub_time_ago( get_the_time( 'U', $post ) ) ); ?></span>
						</span>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
</div>
