<?php
/**
 * Rising Teams widget/shortcode body.
 *
 * @package StrikeHub
 * @var array $args { teams: array }
 */
$teams = isset( $args['teams'] ) ? $args['teams'] : array();
?>
<div class="cs2-widget cs2-rising-teams">
	<?php if ( empty( $teams ) ) : ?>
		<?php strikehub_no_data(); ?>
	<?php else : ?>
		<ul class="cs2-rising-list">
			<?php foreach ( $teams as $row ) : ?>
				<li>
					<span class="movement movement-up">&#9650;</span>
					<a href="<?php echo esc_url( get_permalink( $row['team_id'] ) ); ?>"><?php echo esc_html( get_the_title( $row['team_id'] ) ); ?></a>
					<span class="rising-positions">
						<?php
						/* translators: %d: number of positions gained */
						printf( esc_html__( '+%d positions', 'strikehub' ), (int) $row['movement'] );
						?>
					</span>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
</div>
