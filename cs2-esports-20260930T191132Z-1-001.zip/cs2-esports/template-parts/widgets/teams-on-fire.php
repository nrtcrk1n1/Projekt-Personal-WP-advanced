<?php
/**
 * Teams on Fire widget/shortcode body.
 *
 * @package StrikeHub
 * @var array $args { teams: array }
 */
$teams = isset( $args['teams'] ) ? $args['teams'] : array();
?>
<div class="cs2-widget cs2-teams-on-fire">
	<?php if ( empty( $teams ) ) : ?>
		<?php strikehub_no_data(); ?>
	<?php else : ?>
		<ul class="cs2-fire-list">
			<?php foreach ( $teams as $row ) : ?>
				<li>
					<span class="fire-icon" aria-hidden="true">&#128293;</span>
					<a class="fire-team-name" href="<?php echo esc_url( get_permalink( $row['team_id'] ) ); ?>"><?php echo esc_html( get_the_title( $row['team_id'] ) ); ?></a>
					<span class="fire-detail">
						<?php if ( $row['streak'] >= 3 ) : ?>
							<?php
							/* translators: %d: number of consecutive wins */
							printf( esc_html( _n( '%d match win streak', '%d match win streak', $row['streak'], 'strikehub' ) ), (int) $row['streak'] );
							?>
						<?php else : ?>
							<?php
							/* translators: 1: wins, 2: matches played */
							printf( esc_html__( '%1$d wins in last %2$d', 'strikehub' ), (int) $row['win_count'], (int) $row['played'] );
							?>
						<?php endif; ?>
					</span>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
</div>
