<?php
/**
 * World Ranking widget/shortcode body.
 *
 * @package StrikeHub
 * @var array $args { teams: WP_Post[] }
 */
$teams = isset( $args['teams'] ) ? $args['teams'] : array();
?>
<div class="cs2-widget cs2-world-ranking">
	<?php if ( empty( $teams ) ) : ?>
		<?php strikehub_no_data(); ?>
	<?php else : ?>
		<ol class="cs2-ranking-list">
			<?php foreach ( $teams as $team ) : ?>
				<li>
					<span class="ranking-position">#<?php echo esc_html( strikehub_meta( $team->ID, '_ranking' ) ); ?></span>
					<a class="ranking-name" href="<?php echo esc_url( get_permalink( $team ) ); ?>"><?php echo esc_html( get_the_title( $team ) ); ?></a>
				</li>
			<?php endforeach; ?>
		</ol>
	<?php endif; ?>
</div>
