<?php
/**
 * Players of the Day widget/shortcode body.
 *
 * @package StrikeHub
 * @var array $args { players: array, mode: string }
 */
$players = isset( $args['players'] ) ? $args['players'] : array();
?>
<div class="cs2-widget cs2-players-of-day">
	<?php if ( empty( $players ) ) : ?>
		<?php strikehub_no_data(); ?>
	<?php else : ?>
		<ol class="cs2-players-list">
			<?php foreach ( $players as $i => $row ) : ?>
				<li>
					<span class="ranking-position"><?php echo esc_html( $i + 1 ); ?></span>
					<?php if ( has_post_thumbnail( $row['player_id'] ) ) : ?>
						<span class="player-photo"><?php echo get_the_post_thumbnail( $row['player_id'], 'strikehub-thumb', array( 'loading' => 'lazy' ) ); ?></span>
					<?php endif; ?>
					<span class="player-info">
						<a class="player-name" href="<?php echo esc_url( get_permalink( $row['player_id'] ) ); ?>"><?php echo esc_html( strikehub_meta( $row['player_id'], '_nickname', get_the_title( $row['player_id'] ) ) ); ?></a>
						<span class="player-rating"><?php esc_html_e( 'Rating', 'strikehub' ); ?> <?php echo esc_html( $row['rating'] ); ?></span>
					</span>
				</li>
			<?php endforeach; ?>
		</ol>
	<?php endif; ?>
</div>
