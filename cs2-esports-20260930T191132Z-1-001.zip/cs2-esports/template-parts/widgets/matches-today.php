<?php
/**
 * Matches list widget/shortcode body — reused for "Matches Today",
 * "Upcoming Matches" and "Recent Results" (data differs, markup doesn't).
 *
 * @package StrikeHub
 * @var array $args { matches: WP_Post[] }
 */
$matches = isset( $args['matches'] ) ? $args['matches'] : array();
?>
<div class="cs2-widget cs2-matches">
	<?php if ( empty( $matches ) ) : ?>
		<?php strikehub_no_data(); ?>
	<?php else : ?>
		<ul class="cs2-matches-list">
			<?php foreach ( $matches as $match_post ) : ?>
				<?php $m = strikehub_get_match_data( $match_post->ID ); ?>
				<li class="cs2-match-row status-<?php echo esc_attr( $m['status'] ); ?>">
					<a href="<?php echo esc_url( get_permalink( $match_post ) ); ?>">
						<div class="cs2-match-row-top">
							<?php if ( 'live' === $m['status'] ) : ?>
								<span class="live-dot" aria-hidden="true"></span>
							<?php endif; ?>
							<span class="cs2-match-row-time"
								<?php if ( 'upcoming' === $m['status'] && $m['date'] && $m['time'] ) : ?>
									data-countdown="<?php echo esc_attr( $m['date'] . 'T' . $m['time'] ); ?>"
								<?php endif; ?>
							><?php echo esc_html( $m['time'] ? $m['time'] : '' ); ?></span>
							<?php echo strikehub_status_badge( $m['status'] ); ?>
						</div>
						<div class="cs2-match-row-teams">
							<span><?php echo esc_html( $m['team1_name'] ); ?></span>
							<span class="vs">
								<?php if ( 'final' === $m['status'] || 'live' === $m['status'] ) : ?>
									<?php echo esc_html( $m['score1'] ); ?>&ndash;<?php echo esc_html( $m['score2'] ); ?>
								<?php else : ?>
									vs
								<?php endif; ?>
							</span>
							<span><?php echo esc_html( $m['team2_name'] ); ?></span>
						</div>
						<?php if ( $m['event_name'] ) : ?>
							<div class="cs2-match-row-event"><?php echo esc_html( $m['event_name'] ); ?></div>
						<?php endif; ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
</div>
