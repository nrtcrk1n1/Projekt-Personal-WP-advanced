<?php
/**
 * Trending Today widget/shortcode body. Shows trending articles by view
 * count. Clearly a site-activity metric, not a claim about real-world
 * popularity.
 *
 * @package StrikeHub
 * @var array $args { articles: WP_Post[] }
 */
$articles = isset( $args['articles'] ) ? $args['articles'] : array();
?>
<div class="cs2-widget cs2-trending">
	<?php if ( empty( $articles ) ) : ?>
		<?php strikehub_no_data(); ?>
	<?php else : ?>
		<ol class="cs2-trending-list">
			<?php foreach ( $articles as $i => $post ) : ?>
				<li>
					<span class="ranking-position"><?php echo esc_html( $i + 1 ); ?></span>
					<a href="<?php echo esc_url( get_permalink( $post ) ); ?>"><?php echo esc_html( get_the_title( $post ) ); ?></a>
				</li>
			<?php endforeach; ?>
		</ol>
		<p class="cs2-widget-note"><?php esc_html_e( 'Based on on-site activity, not an external popularity measure.', 'strikehub' ); ?></p>
	<?php endif; ?>
</div>
