<?php
/**
 * Team Form Guide widget/shortcode body.
 *
 * @package StrikeHub
 * @var array $args { rows: array }
 */
$rows = isset( $args['rows'] ) ? $args['rows'] : array();
?>
<div class="cs2-widget cs2-form-guide">
	<?php if ( empty( $rows ) ) : ?>
		<?php strikehub_no_data(); ?>
	<?php else : ?>
		<ul class="cs2-form-list">
			<?php foreach ( $rows as $row ) : ?>
				<li>
					<a class="form-team-name" href="<?php echo esc_url( get_permalink( $row['team_id'] ) ); ?>"><?php echo esc_html( get_the_title( $row['team_id'] ) ); ?></a>
					<span class="form-sequence">
						<?php if ( empty( $row['form'] ) ) : ?>
							<span class="no-data-inline"><?php esc_html_e( 'No data available', 'strikehub' ); ?></span>
						<?php else : ?>
							<?php foreach ( $row['form'] as $result ) : ?>
								<span class="form-pip form-<?php echo 'W' === $result ? 'win' : 'loss'; ?>"><?php echo esc_html( $result ); ?></span>
							<?php endforeach; ?>
						<?php endif; ?>
					</span>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
</div>
