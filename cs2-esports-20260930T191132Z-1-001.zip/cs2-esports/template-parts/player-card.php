<?php
/**
 * Player card. Expects to run inside The Loop for a player post.
 *
 * @package StrikeHub
 */
$player_id = get_the_ID();
$nickname  = strikehub_meta( $player_id, '_nickname', get_the_title() );
$country   = strikehub_meta( $player_id, '_country' );
$team_id   = (int) strikehub_meta( $player_id, '_team_id' );
$rating    = strikehub_meta( $player_id, '_rating' );
?>
<article <?php post_class( 'player-card' ); ?>>
	<a class="player-card-link" href="<?php the_permalink(); ?>">
		<div class="player-card-photo">
			<?php if ( has_post_thumbnail() ) : ?>
				<?php the_post_thumbnail( 'strikehub-card', array( 'loading' => 'lazy' ) ); ?>
			<?php endif; ?>
		</div>
		<div class="player-card-body">
			<h3 class="player-card-name"><?php echo esc_html( $nickname ); ?></h3>
			<p class="player-card-meta">
				<?php echo esc_html( strikehub_flag( $country ) ); ?>
				<?php echo esc_html( $team_id ? get_the_title( $team_id ) : __( 'Free Agent', 'strikehub' ) ); ?>
			</p>
			<?php if ( '' !== $rating ) : ?>
				<p class="player-card-rating"><?php esc_html_e( 'Rating', 'strikehub' ); ?> <strong><?php echo esc_html( $rating ); ?></strong></p>
			<?php endif; ?>
		</div>
	</a>
</article>
