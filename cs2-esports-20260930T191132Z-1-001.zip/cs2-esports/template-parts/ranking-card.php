<?php
/**
 * Single ranking row. Expects $args: position, team_id, points, movement, is_new.
 *
 * @package StrikeHub
 */
$position = isset( $args['position'] ) ? (int) $args['position'] : 0;
$team_id  = isset( $args['team_id'] ) ? (int) $args['team_id'] : 0;
$points   = isset( $args['points'] ) ? $args['points'] : '';
$movement = isset( $args['movement'] ) ? (int) $args['movement'] : 0;
$is_new   = ! empty( $args['is_new'] );

if ( ! $team_id ) {
	return;
}
?>
<div class="ranking-row">
	<span class="ranking-position">#<?php echo esc_html( $position ); ?></span>
	<?php if ( has_post_thumbnail( $team_id ) ) : ?>
		<a href="<?php echo esc_url( get_permalink( $team_id ) ); ?>" class="ranking-logo">
			<?php echo get_the_post_thumbnail( $team_id, 'strikehub-thumb', array( 'loading' => 'lazy' ) ); ?>
		</a>
	<?php endif; ?>
	<a class="ranking-name" href="<?php echo esc_url( get_permalink( $team_id ) ); ?>"><?php echo esc_html( get_the_title( $team_id ) ); ?></a>
	<?php if ( '' !== $points ) : ?><span class="ranking-points"><?php echo esc_html( $points ); ?></span><?php endif; ?>
	<?php echo strikehub_movement_badge( $movement, $is_new ); ?>
</div>
