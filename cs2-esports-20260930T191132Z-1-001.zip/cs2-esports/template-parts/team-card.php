<?php
/**
 * Team card. Expects to run inside The Loop for a team post.
 *
 * @package StrikeHub
 */
$team_id = get_the_ID();
$country = strikehub_meta( $team_id, '_country' );
$ranking = strikehub_meta( $team_id, '_ranking' );
?>
<article <?php post_class( 'team-card' ); ?>>
	<a class="team-card-link" href="<?php the_permalink(); ?>">
		<div class="team-card-logo">
			<?php if ( has_post_thumbnail() ) : ?>
				<?php the_post_thumbnail( 'strikehub-logo', array( 'loading' => 'lazy' ) ); ?>
			<?php endif; ?>
		</div>
		<h3 class="team-card-name"><?php the_title(); ?></h3>
		<p class="team-card-meta">
			<?php echo esc_html( strikehub_flag( $country ) ); ?>
			<?php if ( '' !== $ranking ) : ?>
				<span class="team-card-rank">#<?php echo esc_html( $ranking ); ?></span>
			<?php endif; ?>
		</p>
	</a>
</article>
