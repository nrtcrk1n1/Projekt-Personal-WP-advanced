<?php
/**
 * Event card. Expects to run inside The Loop for an event post.
 *
 * @package StrikeHub
 */
$event_id  = get_the_ID();
$location  = strikehub_meta( $event_id, '_location' );
$prize     = strikehub_meta( $event_id, '_prize_pool' );
$status    = strikehub_meta( $event_id, '_status', 'upcoming' );
?>
<article <?php post_class( 'event-card' ); ?>>
	<a class="event-card-link" href="<?php the_permalink(); ?>">
		<div class="event-card-media">
			<?php if ( has_post_thumbnail() ) : ?>
				<?php the_post_thumbnail( 'strikehub-card', array( 'loading' => 'lazy' ) ); ?>
			<?php endif; ?>
			<span class="status-badge status-<?php echo esc_attr( $status ); ?>"><?php echo esc_html( ucfirst( $status ) ); ?></span>
		</div>
		<div class="event-card-body">
			<h3 class="event-card-name"><?php the_title(); ?></h3>
			<p class="event-card-meta">
				<?php if ( $location ) : ?><span><?php echo esc_html( $location ); ?></span><?php endif; ?>
				<?php if ( $prize ) : ?><span class="event-card-prize"><?php echo esc_html( $prize ); ?></span><?php endif; ?>
			</p>
		</div>
	</a>
</article>
