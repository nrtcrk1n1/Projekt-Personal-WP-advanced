<?php
/**
 * Homepage.
 *
 * @package StrikeHub
 */

get_header();
?>

<div class="layout-three-col">
	<main id="main" class="main-content">

		<?php if ( get_theme_mod( 'show_slider', true ) ) : ?>
			<?php
			$featured = new WP_Query(
				array(
					'posts_per_page' => 6,
					'no_found_rows'  => true,
					'meta_key'       => '_strikehub_featured',
					'meta_value'     => '1',
				)
			);
			if ( ! $featured->have_posts() ) {
				// Fall back to most recent posts so the slider always has content.
				$featured = strikehub_get_news( array( 'posts_per_page' => 6 ) );
			}
			?>
			<?php if ( $featured->have_posts() ) : ?>
				<section class="featured-slider" data-slider aria-roledescription="carousel" aria-label="<?php esc_attr_e( 'Featured news', 'strikehub' ); ?>">
					<div class="slider-track">
						<?php
						$i = 0;
						while ( $featured->have_posts() ) :
							$featured->the_post();
							$categories = get_the_category();
							?>
							<div class="slide" role="group" aria-roledescription="slide" aria-label="<?php echo esc_attr( $i + 1 . ' / ' . $featured->post_count ); ?>" <?php echo 0 === $i ? '' : 'hidden'; ?>>
								<a href="<?php the_permalink(); ?>" class="slide-media">
									<?php if ( has_post_thumbnail() ) : ?>
										<?php the_post_thumbnail( 'strikehub-hero', array( 'loading' => $i === 0 ? 'eager' : 'lazy' ) ); ?>
									<?php endif; ?>
								</a>
								<div class="slide-content">
									<?php if ( $categories ) : ?>
										<span class="slide-category"><?php echo esc_html( $categories[0]->name ); ?></span>
									<?php endif; ?>
									<h2 class="slide-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
									<p class="slide-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 22 ) ); ?></p>
									<div class="slide-meta">
										<span><?php the_author(); ?></span>
										<span aria-hidden="true">&middot;</span>
										<span><?php echo esc_html( strikehub_time_ago( get_the_time( 'U' ) ) ); ?></span>
									</div>
								</div>
							</div>
							<?php
							++$i;
						endwhile;
						wp_reset_postdata();
						?>
					</div>

					<button type="button" class="slider-arrow slider-prev" aria-label="<?php esc_attr_e( 'Previous slide', 'strikehub' ); ?>">&lsaquo;</button>
					<button type="button" class="slider-arrow slider-next" aria-label="<?php esc_attr_e( 'Next slide', 'strikehub' ); ?>">&rsaquo;</button>

					<div class="slider-dots" role="tablist" aria-label="<?php esc_attr_e( 'Slides', 'strikehub' ); ?>">
						<?php for ( $d = 0; $d < $featured->post_count; $d++ ) : ?>
							<button type="button" class="slider-dot <?php echo 0 === $d ? 'is-active' : ''; ?>" role="tab" aria-selected="<?php echo 0 === $d ? 'true' : 'false'; ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %d: slide number */ __( 'Go to slide %d', 'strikehub' ), $d + 1 ) ); ?>"></button>
						<?php endfor; ?>
					</div>
				</section>
			<?php endif; ?>
		<?php endif; ?>

		<?php if ( get_theme_mod( 'show_latest_news', true ) ) : ?>
			<section class="home-section" aria-labelledby="latest-news-heading">
				<div class="home-section-head">
					<h2 id="latest-news-heading"><?php esc_html_e( 'Latest News', 'strikehub' ); ?></h2>
					<a class="section-link" href="<?php echo esc_url( home_url( '/news/' ) ); ?>"><?php esc_html_e( 'All News', 'strikehub' ); ?> &rarr;</a>
				</div>
				<div class="news-grid">
					<?php
					$news = strikehub_get_news( array( 'posts_per_page' => 6 ) );
					if ( $news->have_posts() ) :
						while ( $news->have_posts() ) :
							$news->the_post();
							get_template_part( 'template-parts/news-card' );
						endwhile;
						wp_reset_postdata();
					else :
						strikehub_no_data();
					endif;
					?>
				</div>
			</section>
		<?php endif; ?>

		<?php if ( get_theme_mod( 'show_matches', true ) ) : ?>
			<section class="home-section" aria-labelledby="match-center-heading">
				<div class="home-section-head">
					<h2 id="match-center-heading"><?php esc_html_e( 'Match Center', 'strikehub' ); ?></h2>
					<a class="section-link" href="<?php echo esc_url( get_post_type_archive_link( 'cs2_match' ) ); ?>"><?php esc_html_e( 'All Matches', 'strikehub' ); ?> &rarr;</a>
				</div>
				<div class="match-tabs" data-tabs>
					<div class="tab-buttons" role="tablist">
						<button type="button" class="tab-btn is-active" role="tab" data-tab="upcoming"><?php esc_html_e( 'Upcoming', 'strikehub' ); ?></button>
						<button type="button" class="tab-btn" role="tab" data-tab="live"><?php esc_html_e( 'Live', 'strikehub' ); ?></button>
						<button type="button" class="tab-btn" role="tab" data-tab="results"><?php esc_html_e( 'Results', 'strikehub' ); ?></button>
					</div>
					<div class="tab-panel match-grid" data-tab-panel="upcoming">
						<?php
						$upcoming = strikehub_get_matches_by_status( 'upcoming', 6 );
						if ( $upcoming->have_posts() ) :
							while ( $upcoming->have_posts() ) :
								$upcoming->the_post();
								get_template_part( 'template-parts/match-card' );
							endwhile;
							wp_reset_postdata();
						else :
							strikehub_no_data();
						endif;
						?>
					</div>
					<div class="tab-panel match-grid" data-tab-panel="live" hidden>
						<?php
						$live = strikehub_get_matches_by_status( 'live', 6 );
						if ( $live->have_posts() ) :
							while ( $live->have_posts() ) :
								$live->the_post();
								get_template_part( 'template-parts/match-card' );
							endwhile;
							wp_reset_postdata();
						else :
							strikehub_no_data();
						endif;
						?>
					</div>
					<div class="tab-panel match-grid" data-tab-panel="results" hidden>
						<?php
						$results = strikehub_get_matches_by_status( 'final', 6 );
						if ( $results->have_posts() ) :
							while ( $results->have_posts() ) :
								$results->the_post();
								get_template_part( 'template-parts/match-card' );
							endwhile;
							wp_reset_postdata();
						else :
							strikehub_no_data();
						endif;
						?>
					</div>
				</div>
			</section>
		<?php endif; ?>

		<?php if ( get_theme_mod( 'show_players', true ) ) : ?>
			<section class="home-section" aria-labelledby="players-heading">
				<div class="home-section-head">
					<h2 id="players-heading"><?php esc_html_e( 'Players of the Day', 'strikehub' ); ?></h2>
				</div>
				<?php get_template_part( 'template-parts/widgets/players-of-day', null, array( 'players' => cs2_get_players_of_the_day( 5 ) ) ); ?>
			</section>
		<?php endif; ?>

		<?php if ( get_theme_mod( 'show_fire', true ) ) : ?>
			<section class="home-section" aria-labelledby="fire-heading">
				<div class="home-section-head">
					<h2 id="fire-heading"><?php esc_html_e( 'Teams on Fire', 'strikehub' ); ?></h2>
				</div>
				<?php get_template_part( 'template-parts/widgets/teams-on-fire', null, array( 'teams' => cs2_get_teams_on_fire( 5 ) ) ); ?>
			</section>
		<?php endif; ?>

		<?php if ( get_theme_mod( 'show_transfers', true ) ) : ?>
			<section class="home-section" aria-labelledby="transfers-heading">
				<div class="home-section-head">
					<h2 id="transfers-heading"><?php esc_html_e( 'Latest Transfers', 'strikehub' ); ?></h2>
					<a class="section-link" href="<?php echo esc_url( get_post_type_archive_link( 'transfer' ) ); ?>"><?php esc_html_e( 'All Transfers', 'strikehub' ); ?> &rarr;</a>
				</div>
				<table class="transfers-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Player', 'strikehub' ); ?></th>
							<th><?php esc_html_e( 'From', 'strikehub' ); ?></th>
							<th><?php esc_html_e( 'To', 'strikehub' ); ?></th>
							<th><?php esc_html_e( 'Date', 'strikehub' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php
						$transfers = get_posts( array( 'post_type' => 'transfer', 'posts_per_page' => 6 ) );
						if ( $transfers ) :
							foreach ( $transfers as $t ) :
								$player_id = (int) strikehub_meta( $t->ID, '_player_id' );
								$from_id   = (int) strikehub_meta( $t->ID, '_from_team_id' );
								$to_id     = (int) strikehub_meta( $t->ID, '_to_team_id' );
								?>
								<tr>
									<td><a href="<?php echo esc_url( get_permalink( $t ) ); ?>"><?php echo esc_html( $player_id ? get_the_title( $player_id ) : get_the_title( $t ) ); ?></a></td>
									<td><?php echo esc_html( $from_id ? get_the_title( $from_id ) : '—' ); ?></td>
									<td><?php echo esc_html( $to_id ? get_the_title( $to_id ) : '—' ); ?></td>
									<td><?php echo esc_html( strikehub_meta( $t->ID, '_transfer_date' ) ); ?></td>
								</tr>
								<?php
							endforeach;
						else :
							?>
							<tr><td colspan="4"><?php strikehub_no_data(); ?></td></tr>
							<?php
						endif;
						?>
					</tbody>
				</table>
			</section>
		<?php endif; ?>

		<?php if ( get_theme_mod( 'show_popular', true ) ) : ?>
			<section class="home-section" aria-labelledby="popular-heading">
				<div class="home-section-head">
					<h2 id="popular-heading"><?php esc_html_e( 'Popular Articles', 'strikehub' ); ?></h2>
				</div>
				<div class="news-grid news-grid-compact">
					<?php
					$popular = strikehub_get_popular_news( 4 );
					if ( $popular->have_posts() ) :
						while ( $popular->have_posts() ) :
							$popular->the_post();
							get_template_part( 'template-parts/news-card' );
						endwhile;
						wp_reset_postdata();
					else :
						strikehub_no_data();
					endif;
					?>
				</div>
			</section>
		<?php endif; ?>

	</main>

	<?php get_sidebar(); ?>
</div>

<?php get_footer(); ?>
