<?php
/**
 * Player archive with AJAX filters.
 *
 * @package StrikeHub
 */

get_header();
$roles = get_terms( array( 'taxonomy' => 'player_role', 'hide_empty' => true ) );
?>
<div class="layout-three-col">
	<main id="main" class="main-content">
		<?php strikehub_breadcrumbs(); ?>
		<h1 class="archive-title"><?php esc_html_e( 'Players', 'strikehub' ); ?></h1>

		<form class="filter-bar" data-ajax-filter="players">
			<label class="screen-reader-text" for="player-filter-country"><?php esc_html_e( 'Country', 'strikehub' ); ?></label>
			<input type="text" id="player-filter-country" name="country" placeholder="<?php esc_attr_e( 'Country (e.g. RU)', 'strikehub' ); ?>">

			<label class="screen-reader-text" for="player-filter-role"><?php esc_html_e( 'Role', 'strikehub' ); ?></label>
			<select id="player-filter-role" name="role">
				<option value=""><?php esc_html_e( 'All Roles', 'strikehub' ); ?></option>
				<?php if ( ! is_wp_error( $roles ) ) : ?>
					<?php foreach ( $roles as $role ) : ?>
						<option value="<?php echo esc_attr( $role->slug ); ?>"><?php echo esc_html( $role->name ); ?></option>
					<?php endforeach; ?>
				<?php endif; ?>
			</select>
		</form>

		<div class="player-grid" id="player-filter-results">
			<?php if ( have_posts() ) : ?>
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/player-card' );
				endwhile;
				?>
			<?php else : ?>
				<?php strikehub_no_data(); ?>
			<?php endif; ?>
		</div>

		<?php strikehub_pagination(); ?>
	</main>

	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
