<?php
/**
 * Generic archive template for category, tag, date, and author archives.
 *
 * @package StrikeHub
 */

get_header();
?>
<div class="layout-three-col">
	<main id="main" class="main-content">
		<?php strikehub_breadcrumbs(); ?>
		<h1 class="archive-title"><?php the_archive_title(); ?></h1>
		<?php the_archive_description( '<div class="archive-description">', '</div>' ); ?>

		<div class="news-grid">
			<?php if ( have_posts() ) : ?>
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/news-card' );
				endwhile;
				?>
			<?php else : ?>
				<?php strikehub_no_data(); ?>
			<?php endif; ?>
		</div>

		<?php strikehub_pagination(); ?>
	</main>

	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
