<?php
/**
 * Fallback template: blog index and anything without a more specific match.
 *
 * @package StrikeHub
 */

get_header();
?>
<div class="layout-three-col">
	<main id="main" class="main-content">
		<?php strikehub_breadcrumbs(); ?>

		<?php if ( is_home() && ! is_front_page() ) : ?>
			<h1 class="archive-title"><?php esc_html_e( 'News', 'strikehub' ); ?></h1>
		<?php endif; ?>

		<div class="news-grid">
			<?php if ( have_posts() ) : ?>
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/news-card' );
				endwhile;
				?>
			<?php else : ?>
				<?php strikehub_no_data( __( 'No posts found.', 'strikehub' ) ); ?>
			<?php endif; ?>
		</div>

		<?php strikehub_pagination(); ?>
	</main>

	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
