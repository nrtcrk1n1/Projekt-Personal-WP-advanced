<?php
/**
 * Single team profile.
 *
 * @package StrikeHub
 */

get_header();

while ( have_posts() ) :
	the_post();
	$id      = get_the_ID();
	$country = strikehub_meta( $id, '_country' );
	$coach   = strikehub_meta( $id, '_coach' );
	$ranking = strikehub_meta( $id, '_ranking' );
	$wins    = strikehub_meta( $id, '_wins', 0 );
	$losses  = strikehub_meta( $id, '_losses', 0 );
	$form    = strikehub_get_team_form( $id, 5 );

	$roster = strikehub_get_players( array( 'meta_key' => '_team_id', 'meta_value' => $id ) );
	?>
	<div class="layout-three-col">
		<main id="main" class="main-content">
			<?php strikehub_breadcrumbs(); ?>

			<header class="profile-header team-profile-header">
				<div class="profile-logo">
					<?php if ( has_post_thumbnail() ) : ?>
						<?php the_post_thumbnail( 'strikehub-logo' ); ?>
					<?php endif; ?>
				</div>
				<div class="profile-info">
					<h1 class="profile-name"><?php the_title(); ?></h1>
					<p class="profile-tagline">
						<?php echo esc_html( strikehub_flag( $country ) ); ?> <?php echo esc_html( $country ); ?>
						<?php if ( '' !== $ranking ) : ?><span aria-hidden="true">&middot;</span> <?php esc_html_e( 'World Rank', 'strikehub' ); ?> #<?php echo esc_html( $ranking ); ?><?php endif; ?>
					</p>
					<?php if ( $coach ) : ?><p><?php esc_html_e( 'Coach:', 'strikehub' ); ?> <?php echo esc_html( $coach ); ?></p><?php endif; ?>
					<p class="profile-record"><?php echo esc_html( $wins ); ?>W &ndash; <?php echo esc_html( $losses ); ?>L</p>
					<?php if ( $form ) : ?>
						<p class="profile-form">
							<?php foreach ( $form as $r ) : ?>
								<span class="form-pip form-<?php echo 'W' === $r ? 'win' : 'loss'; ?>"><?php echo esc_html( $r ); ?></span>
							<?php endforeach; ?>
						</p>
					<?php endif; ?>
				</div>
			</header>

			<section class="roster-section">
				<h2><?php esc_html_e( 'Current Roster', 'strikehub' ); ?></h2>
				<?php if ( $roster->have_posts() ) : ?>
					<div class="roster-grid">
						<?php
						while ( $roster->have_posts() ) :
							$roster->the_post();
							$role_terms = get_the_terms( get_the_ID(), 'player_role' );
							$role       = ( $role_terms && ! is_wp_error( $role_terms ) ) ? $role_terms[0]->name : '';
							?>
							<a class="roster-card" href="<?php the_permalink(); ?>">
								<?php if ( has_post_thumbnail() ) : ?>
									<?php the_post_thumbnail( 'strikehub-thumb' ); ?>
								<?php endif; ?>
								<span class="roster-name"><?php echo esc_html( strikehub_meta( get_the_ID(), '_nickname', get_the_title() ) ); ?></span>
								<?php if ( $role ) : ?><span class="roster-role"><?php echo esc_html( $role ); ?></span><?php endif; ?>
								<span class="roster-country"><?php echo esc_html( strikehub_flag( strikehub_meta( get_the_ID(), '_country' ) ) ); ?></span>
							</a>
							<?php
						endwhile;
						wp_reset_postdata();
						?>
					</div>
				<?php else : ?>
					<?php strikehub_no_data(); ?>
				<?php endif; ?>
			</section>

			<?php if ( get_the_content() ) : ?>
				<section class="profile-bio">
					<h2><?php esc_html_e( 'About', 'strikehub' ); ?></h2>
					<div class="article-content"><?php the_content(); ?></div>
				</section>
			<?php endif; ?>

			<section class="recent-matches-section">
				<h2><?php esc_html_e( 'Recent Results & Upcoming Matches', 'strikehub' ); ?></h2>
				<?php
				$matches = strikehub_get_team_matches( $id, 8 );
				if ( $matches->have_posts() ) :
					?>
					<div class="match-grid">
						<?php
						while ( $matches->have_posts() ) :
							$matches->the_post();
							get_template_part( 'template-parts/match-card' );
						endwhile;
						wp_reset_postdata();
						?>
					</div>
					<?php
				else :
					strikehub_no_data();
				endif;
				?>
			</section>

			<section class="recent-news-section">
				<h2><?php esc_html_e( 'Team News', 'strikehub' ); ?></h2>
				<?php
				$news = new WP_Query( array( 's' => get_the_title( $id ), 'posts_per_page' => 3, 'no_found_rows' => true ) );
				if ( $news->have_posts() ) :
					?>
					<div class="news-grid">
						<?php
						while ( $news->have_posts() ) :
							$news->the_post();
							get_template_part( 'template-parts/news-card' );
						endwhile;
						wp_reset_postdata();
						?>
					</div>
					<?php
				else :
					strikehub_no_data();
				endif;
				?>
			</section>
		</main>

		<?php get_sidebar(); ?>
	</div>
	<?php
endwhile;

get_footer();
