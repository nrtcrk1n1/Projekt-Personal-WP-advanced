<?php
/**
 * StrikeHub theme bootstrap.
 *
 * @package StrikeHub
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'STRIKEHUB_VERSION', '1.0.0' );
define( 'STRIKEHUB_DIR', get_template_directory() );
define( 'STRIKEHUB_URI', get_template_directory_uri() );

/**
 * Load includes. Every feature area lives in its own file under /inc.
 */
require STRIKEHUB_DIR . '/inc/setup.php';
require STRIKEHUB_DIR . '/inc/helpers.php';
require STRIKEHUB_DIR . '/inc/post-types.php';
require STRIKEHUB_DIR . '/inc/taxonomies.php';
require STRIKEHUB_DIR . '/inc/meta-boxes.php';
require STRIKEHUB_DIR . '/inc/queries.php';
require STRIKEHUB_DIR . '/inc/ranking.php';
require STRIKEHUB_DIR . '/inc/widgets.php';
require STRIKEHUB_DIR . '/inc/shortcodes.php';
require STRIKEHUB_DIR . '/inc/rest-api.php';
require STRIKEHUB_DIR . '/inc/ajax.php';
require STRIKEHUB_DIR . '/inc/customizer.php';
require STRIKEHUB_DIR . '/inc/template-functions.php';
require STRIKEHUB_DIR . '/inc/admin.php';

/**
 * Theme support & basic setup.
 */
function strikehub_setup() {
	load_theme_textdomain( 'strikehub', STRIKEHUB_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );

	// Image sizes used across cards, sliders and profile headers.
	set_post_thumbnail_size( 800, 450, true );
	add_image_size( 'strikehub-hero', 1280, 640, true );
	add_image_size( 'strikehub-card', 480, 270, true );
	add_image_size( 'strikehub-thumb', 120, 120, true );
	add_image_size( 'strikehub-logo', 200, 200, false );

	register_nav_menus(
		array(
			'primary'   => __( 'Primary Navigation', 'strikehub' ),
			'secondary' => __( 'Secondary Navigation', 'strikehub' ),
			'mobile'    => __( 'Mobile Navigation', 'strikehub' ),
			'footer'    => __( 'Footer Navigation', 'strikehub' ),
		)
	);
}
add_action( 'after_setup_theme', 'strikehub_setup' );

/**
 * Content width for embeds/oEmbed.
 */
function strikehub_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'strikehub_content_width', 860 );
}
add_action( 'after_setup_theme', 'strikehub_content_width', 0 );

/**
 * Enqueue styles & scripts. Scripts that are only needed on specific
 * templates are gated behind conditional tags so nothing loads globally
 * that doesn't have to.
 */
function strikehub_scripts() {
	wp_enqueue_style( 'strikehub-style', get_stylesheet_uri(), array(), STRIKEHUB_VERSION );
	wp_enqueue_style( 'strikehub-main', STRIKEHUB_URI . '/assets/css/main.css', array( 'strikehub-style' ), STRIKEHUB_VERSION );
	wp_enqueue_style( 'strikehub-responsive', STRIKEHUB_URI . '/assets/css/responsive.css', array( 'strikehub-main' ), STRIKEHUB_VERSION );

	wp_enqueue_script( 'strikehub-main', STRIKEHUB_URI . '/assets/js/main.js', array(), STRIKEHUB_VERSION, true );

	// Slider only where a slider actually renders.
	if ( is_front_page() || is_singular( array( 'player', 'team' ) ) ) {
		wp_enqueue_script( 'strikehub-slider', STRIKEHUB_URI . '/assets/js/slider.js', array(), STRIKEHUB_VERSION, true );
	}

	wp_enqueue_script( 'strikehub-ajax', STRIKEHUB_URI . '/assets/js/ajax.js', array(), STRIKEHUB_VERSION, true );

	wp_localize_script(
		'strikehub-ajax',
		'StrikeHubAjax',
		array(
			'url'    => admin_url( 'admin-ajax.php' ),
			'nonce'  => wp_create_nonce( 'strikehub_ajax_nonce' ),
			'restUrl'=> esc_url_raw( rest_url( 'cs2/v1/' ) ),
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'strikehub_scripts' );

/**
 * Admin-only styles for meta boxes.
 */
function strikehub_admin_scripts( $hook ) {
	global $post_type;
	$cs2_types = array( 'player', 'team', 'cs2_match', 'event' );
	if ( in_array( $post_type, $cs2_types, true ) ) {
		wp_enqueue_style( 'strikehub-admin', STRIKEHUB_URI . '/assets/css/admin.css', array(), STRIKEHUB_VERSION );
	}
}
add_action( 'admin_enqueue_scripts', 'strikehub_admin_scripts' );

/**
 * Register widget areas.
 */
function strikehub_widgets_init() {
	$areas = array(
		'main-sidebar'      => __( 'Main Sidebar', 'strikehub' ),
		'homepage-sidebar'  => __( 'Homepage Sidebar', 'strikehub' ),
		'news-sidebar'      => __( 'News Sidebar', 'strikehub' ),
		'match-sidebar'     => __( 'Match Sidebar', 'strikehub' ),
		'player-sidebar'    => __( 'Player Sidebar', 'strikehub' ),
		'team-sidebar'      => __( 'Team Sidebar', 'strikehub' ),
		'event-sidebar'     => __( 'Event Sidebar', 'strikehub' ),
		'footer-column-1'   => __( 'Footer Column 1', 'strikehub' ),
		'footer-column-2'   => __( 'Footer Column 2', 'strikehub' ),
		'footer-column-3'   => __( 'Footer Column 3', 'strikehub' ),
	);

	foreach ( $areas as $id => $name ) {
		register_sidebar(
			array(
				'name'          => $name,
				'id'            => $id,
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<h3 class="widget-title">',
				'after_title'   => '</h3>',
			)
		);
	}
}
add_action( 'widgets_init', 'strikehub_widgets_init' );
