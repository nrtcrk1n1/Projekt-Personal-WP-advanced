</div><!-- #primary-content -->

<footer id="colophon" class="site-footer">
	<div class="footer-columns">
		<div class="footer-col">
			<h3><?php bloginfo( 'name' ); ?></h3>
			<ul>
				<li><a href="<?php echo esc_url( home_url( '/news/' ) ); ?>"><?php esc_html_e( 'News', 'strikehub' ); ?></a></li>
				<li><a href="<?php echo esc_url( get_post_type_archive_link( 'cs2_match' ) ); ?>"><?php esc_html_e( 'Matches', 'strikehub' ); ?></a></li>
				<li><a href="<?php echo esc_url( get_post_type_archive_link( 'player' ) ); ?>"><?php esc_html_e( 'Players', 'strikehub' ); ?></a></li>
				<li><a href="<?php echo esc_url( get_post_type_archive_link( 'team' ) ); ?>"><?php esc_html_e( 'Teams', 'strikehub' ); ?></a></li>
				<li><a href="<?php echo esc_url( get_post_type_archive_link( 'event' ) ); ?>"><?php esc_html_e( 'Events', 'strikehub' ); ?></a></li>
			</ul>
		</div>

		<div class="footer-col">
			<h3><?php esc_html_e( 'Community', 'strikehub' ); ?></h3>
			<ul>
				<?php
				$socials = array(
					'discord_url' => __( 'Discord', 'strikehub' ),
					'twitter_url' => __( 'Twitter / X', 'strikehub' ),
					'youtube_url' => __( 'YouTube', 'strikehub' ),
					'twitch_url'  => __( 'Twitch', 'strikehub' ),
				);
				foreach ( $socials as $mod => $label ) {
					$url = get_theme_mod( $mod, '' );
					if ( $url ) {
						echo '<li><a href="' . esc_url( $url ) . '" rel="noopener" target="_blank">' . esc_html( $label ) . '</a></li>';
					}
				}
				?>
				<li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Contact', 'strikehub' ); ?></a></li>
			</ul>
			<?php if ( is_active_sidebar( 'footer-column-1' ) ) : ?>
				<?php dynamic_sidebar( 'footer-column-1' ); ?>
			<?php endif; ?>
		</div>

		<div class="footer-col">
			<h3><?php esc_html_e( 'Legal', 'strikehub' ); ?></h3>
			<ul>
				<li><a href="<?php echo esc_url( home_url( '/privacy/' ) ); ?>"><?php esc_html_e( 'Privacy', 'strikehub' ); ?></a></li>
				<li><a href="<?php echo esc_url( home_url( '/terms/' ) ); ?>"><?php esc_html_e( 'Terms', 'strikehub' ); ?></a></li>
				<li><a href="<?php echo esc_url( home_url( '/cookies/' ) ); ?>"><?php esc_html_e( 'Cookie Policy', 'strikehub' ); ?></a></li>
			</ul>
			<?php if ( is_active_sidebar( 'footer-column-2' ) ) : ?>
				<?php dynamic_sidebar( 'footer-column-2' ); ?>
			<?php endif; ?>
		</div>

		<?php if ( is_active_sidebar( 'footer-column-3' ) ) : ?>
			<div class="footer-col">
				<?php dynamic_sidebar( 'footer-column-3' ); ?>
			</div>
		<?php endif; ?>
	</div>

	<div class="footer-bottom">
		<?php
		$footer_text = get_theme_mod( 'footer_text', '' );
		if ( $footer_text ) {
			echo wp_kses_post( wpautop( $footer_text ) );
		} else {
			printf(
				/* translators: 1: year, 2: site name */
				esc_html__( '&copy; %1$s %2$s. All rights reserved.', 'strikehub' ),
				esc_html( gmdate( 'Y' ) ),
				esc_html( get_bloginfo( 'name' ) )
			);
		}
		?>
	</div>
</footer>

<button type="button" id="back-to-top" class="back-to-top" aria-label="<?php esc_attr_e( 'Back to top', 'strikehub' ); ?>">&uarr;</button>

<?php wp_footer(); ?>
</body>
</html>
