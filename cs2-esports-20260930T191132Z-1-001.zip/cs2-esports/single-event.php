<?php
/**
 * Single event/tournament page.
 *
 * @package StrikeHub
 */

get_header();

while ( have_posts() ) :
	the_post();
	$id         = get_the_ID();
	$organizer  = strikehub_meta( $id, '_organizer' );
	$location   = strikehub_meta( $id, '_location' );
	$prize      = strikehub_meta( $id, '_prize_pool' );
	$start      = strikehub_meta( $id, '_start_date' );
	$end        = strikehub_meta( $id, '_end_date' );
	$status     = strikehub_meta( $id, '_status', 'upcoming' );

	$matches = strikehub_get_matches( array( 'posts_per_page' => 30, 'meta_query' => array( array( 'key' => '_event_id', 'value' => $id ) ) ) );
	?>
	<div class="layout-single-col">
		<main id="main" class="main-content">
			<?php strikehub_breadcrumbs(); ?>

			<header class="event-header">
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="event-header-logo"><?php the_post_thumbnail( 'strikehub-logo' ); ?></div>
				<?php endif; ?>
				<h1><?php the_title(); ?></h1>
				<p class="event-header-meta">
					<?php if ( $location ) : ?><span><?php echo esc_html( $location ); ?></span><?php endif; ?>
					<?php if ( $start ) : ?><span><?php echo esc_html( $start ); ?><?php echo $end ? ' &ndash; ' . esc_html( $end ) : ''; ?></span><?php endif; ?>
					<?php echo strikehub_status_badge( 'ongoing' === $status ? 'live' : ( 'finished' === $status ? 'final' : 'upcoming' ) ); ?>
				</p>
				<?php if ( $prize ) : ?><p class="event-prize-pool"><?php esc_html_e( 'Prize Pool:', 'strikehub' ); ?> <strong><?php echo esc_html( $prize ); ?></strong></p><?php endif; ?>
				<?php if ( $organizer ) : ?><p><?php esc_html_e( 'Organizer:', 'strikehub' ); ?> <?php echo esc_html( $organizer ); ?></p><?php endif; ?>
			</header>

			<div class="event-tabs" data-tabs>
				<div class="tab-buttons" role="tablist">
					<button type="button" class="tab-btn is-active" role="tab" data-tab="overview"><?php esc_html_e( 'Overview', 'strikehub' ); ?></button>
					<button type="button" class="tab-btn" role="tab" data-tab="matches"><?php esc_html_e( 'Matches', 'strikehub' ); ?></button>
					<button type="button" class="tab-btn" role="tab" data-tab="standings"><?php esc_html_e( 'Standings', 'strikehub' ); ?></button>
					<button type="button" class="tab-btn" role="tab" data-tab="bracket"><?php esc_html_e( 'Bracket', 'strikehub' ); ?></button>
					<button type="button" class="tab-btn" role="tab" data-tab="news"><?php esc_html_e( 'News', 'strikehub' ); ?></button>
				</div>

				<div class="tab-panel" data-tab-panel="overview">
					<?php if ( get_the_content() ) : ?>
						<div class="article-content"><?php the_content(); ?></div>
					<?php else : ?>
						<?php strikehub_no_data(); ?>
					<?php endif; ?>
				</div>

				<div class="tab-panel match-grid" data-tab-panel="matches" hidden>
					<?php
					if ( $matches->have_posts() ) :
						while ( $matches->have_posts() ) :
							$matches->the_post();
							get_template_part( 'template-parts/match-card' );
						endwhile;
						wp_reset_postdata();
					else :
						strikehub_no_data();
					endif;
					?>
				</div>

				<div class="tab-panel" data-tab-panel="standings" hidden>
					<?php
					// Standings derived from teams that have played in this event's matches.
					$team_ids = array();
					foreach ( $matches->posts as $m ) {
						$t1 = (int) strikehub_meta( $m->ID, '_team1_id' );
						$t2 = (int) strikehub_meta( $m->ID, '_team2_id' );
						if ( $t1 ) {
							$team_ids[ $t1 ] = true;
						}
						if ( $t2 ) {
							$team_ids[ $t2 ] = true;
						}
					}
					if ( $team_ids ) :
						?>
						<div class="standings-list">
							<?php
							$position = 1;
							foreach ( array_keys( $team_ids ) as $team_id ) :
								get_template_part(
									'template-parts/ranking-card',
									null,
									array(
										'position' => $position++,
										'team_id'  => $team_id,
										'points'   => strikehub_meta( $team_id, '_ranking_points' ),
										'movement' => 0,
									)
								);
							endforeach;
							?>
						</div>
						<?php
					else :
						strikehub_no_data();
					endif;
					?>
				</div>

				<div class="tab-panel" data-tab-panel="bracket" hidden>
					<?php strikehub_no_data( __( 'Bracket data has not been entered for this event yet.', 'strikehub' ) ); ?>
				</div>

				<div class="tab-panel news-grid" data-tab-panel="news" hidden>
					<?php
					$news = new WP_Query( array( 's' => get_the_title( $id ), 'posts_per_page' => 6, 'no_found_rows' => true ) );
					if ( $news->have_posts() ) :
						while ( $news->have_posts() ) :
							$news->the_post();
							get_template_part( 'template-parts/news-card' );
						endwhile;
						wp_reset_postdata();
					else :
						strikehub_no_data();
					endif;
					?>
				</div>
			</div>
		</main>
	</div>
	<?php
endwhile;

get_footer();
