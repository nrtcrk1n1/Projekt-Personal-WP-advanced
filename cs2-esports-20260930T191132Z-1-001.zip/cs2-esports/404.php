<?php
/**
 * 404 template.
 *
 * @package StrikeHub
 */

get_header();
?>
<div class="layout-single-col">
	<main id="main" class="main-content error-404-content">
		<h1><?php esc_html_e( 'Page not found', 'strikehub' ); ?></h1>
		<p><?php esc_html_e( 'The page you were looking for doesn\u2019t exist, or the round already ended.', 'strikehub' ); ?></p>

		<form role="search" method="get" class="inline-search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label class="screen-reader-text" for="search-404"><?php esc_html_e( 'Search', 'strikehub' ); ?></label>
			<input type="search" id="search-404" name="s" placeholder="<?php esc_attr_e( 'Search news, players, teams…', 'strikehub' ); ?>">
			<button type="submit"><?php esc_html_e( 'Search', 'strikehub' ); ?></button>
		</form>

		<div class="error-404-links">
			<a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Go Home', 'strikehub' ); ?></a>
			<a class="btn" href="<?php echo esc_url( get_post_type_archive_link( 'cs2_match' ) ); ?>"><?php esc_html_e( 'View Matches', 'strikehub' ); ?></a>
		</div>
	</main>
</div>
<?php get_footer(); ?>
