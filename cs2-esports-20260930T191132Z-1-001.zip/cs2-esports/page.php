<?php
/**
 * Static page template.
 *
 * @package StrikeHub
 */

get_header();
?>
<div class="layout-single-col">
	<main id="main" class="main-content">
		<?php strikehub_breadcrumbs(); ?>
		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<article <?php post_class( 'page-content-wrap' ); ?>>
				<h1 class="page-title"><?php the_title(); ?></h1>
				<?php if ( has_post_thumbnail() ) : ?>
					<figure class="article-featured-image"><?php the_post_thumbnail( 'strikehub-hero' ); ?></figure>
				<?php endif; ?>
				<div class="article-content">
					<?php the_content(); ?>
				</div>
				<?php if ( comments_open() || get_comments_number() ) : ?>
					<?php comments_template(); ?>
				<?php endif; ?>
			</article>
			<?php
		endwhile;
		?>
	</main>
</div>
<?php get_footer(); ?>
