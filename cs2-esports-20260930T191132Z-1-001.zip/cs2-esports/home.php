<?php
/**
 * Blog posts index (used when a static homepage is set and a separate
 * "Posts page" is chosen in Settings > Reading). Includes AJAX filters.
 *
 * @package StrikeHub
 */

get_header();
$categories = get_categories( array( 'hide_empty' => true ) );
?>
<div class="layout-three-col">
	<main id="main" class="main-content">
		<h1 class="archive-title"><?php esc_html_e( 'News', 'strikehub' ); ?></h1>

		<form class="filter-bar" data-ajax-filter="news">
			<label class="screen-reader-text" for="news-filter-category"><?php esc_html_e( 'Category', 'strikehub' ); ?></label>
			<select id="news-filter-category" name="category">
				<option value=""><?php esc_html_e( 'All Categories', 'strikehub' ); ?></option>
				<?php foreach ( $categories as $cat ) : ?>
					<option value="<?php echo esc_attr( $cat->slug ); ?>"><?php echo esc_html( $cat->name ); ?></option>
				<?php endforeach; ?>
			</select>
			<label class="screen-reader-text" for="news-filter-date"><?php esc_html_e( 'Date', 'strikehub' ); ?></label>
			<input type="date" id="news-filter-date" name="date">
		</form>

		<div class="news-grid" id="news-filter-results">
			<?php
			$news = strikehub_get_news( array( 'posts_per_page' => 10, 'paged' => max( 1, get_query_var( 'paged' ) ) ) );
			if ( $news->have_posts() ) :
				while ( $news->have_posts() ) :
					$news->the_post();
					get_template_part( 'template-parts/news-card' );
				endwhile;
				wp_reset_postdata();
			else :
				strikehub_no_data();
			endif;
			?>
		</div>

		<?php strikehub_pagination(); ?>
	</main>

	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
