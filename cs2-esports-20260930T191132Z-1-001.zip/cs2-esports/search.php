<?php
/**
 * Search results, grouped by content type.
 *
 * @package StrikeHub
 */

get_header();

$query_string = get_search_query();
$groups       = array(
	'post'   => array( 'label' => __( 'News', 'strikehub' ), 'items' => array() ),
	'player' => array( 'label' => __( 'Players', 'strikehub' ), 'items' => array() ),
	'team'   => array( 'label' => __( 'Teams', 'strikehub' ), 'items' => array() ),
	'event'  => array( 'label' => __( 'Events', 'strikehub' ), 'items' => array() ),
);

while ( have_posts() ) {
	the_post();
	$type = get_post_type();
	if ( isset( $groups[ $type ] ) ) {
		$groups[ $type ]['items'][] = get_the_ID();
	}
}
?>
<div class="layout-single-col">
	<main id="main" class="main-content">
		<h1 class="archive-title">
			<?php
			printf(
				/* translators: %s: search term */
				esc_html__( 'Search results for &ldquo;%s&rdquo;', 'strikehub' ),
				esc_html( $query_string )
			);
			?>
		</h1>

		<?php
		$has_any = false;
		foreach ( $groups as $type => $group ) :
			if ( empty( $group['items'] ) ) {
				continue;
			}
			$has_any = true;
			?>
			<section class="search-group">
				<h2 class="search-group-label"><?php echo esc_html( strtoupper( $group['label'] ) ); ?></h2>
				<ul class="search-group-list">
					<?php foreach ( $group['items'] as $post_id ) : ?>
						<li><a href="<?php echo esc_url( get_permalink( $post_id ) ); ?>"><?php echo esc_html( get_the_title( $post_id ) ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			</section>
			<?php
		endforeach;

		if ( ! $has_any ) :
			strikehub_no_data( __( 'No results found. Try a different search term.', 'strikehub' ) );
		endif;
		?>

		<?php strikehub_pagination(); ?>

		<form role="search" method="get" class="inline-search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label class="screen-reader-text" for="search-again"><?php esc_html_e( 'Search again', 'strikehub' ); ?></label>
			<input type="search" id="search-again" name="s" value="<?php echo esc_attr( $query_string ); ?>">
			<button type="submit"><?php esc_html_e( 'Search', 'strikehub' ); ?></button>
		</form>
	</main>
</div>
<?php get_footer(); ?>
