/**
 * StrikeHub main.js
 * Mobile menu, search overlay, tabs, back-to-top, match countdowns.
 * Vanilla JS only — no dependencies.
 */
( function () {
	'use strict';

	var reducedMotion = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

	/* ---------------------------------------------------------- */
	/* Mobile menu                                                  */
	/* ---------------------------------------------------------- */
	function initMobileMenu() {
		var toggle = document.querySelector( '.mobile-menu-toggle' );
		var menu   = document.getElementById( 'mobile-menu' );
		var close  = menu ? menu.querySelector( '.mobile-menu-close' ) : null;

		if ( ! toggle || ! menu ) {
			return;
		}

		function open() {
			menu.classList.add( 'is-open' );
			menu.setAttribute( 'aria-hidden', 'false' );
			toggle.setAttribute( 'aria-expanded', 'true' );
			document.body.style.overflow = 'hidden';
			var firstLink = menu.querySelector( 'a, button' );
			if ( firstLink ) {
				firstLink.focus();
			}
		}
		function closeMenu() {
			menu.classList.remove( 'is-open' );
			menu.setAttribute( 'aria-hidden', 'true' );
			toggle.setAttribute( 'aria-expanded', 'false' );
			document.body.style.overflow = '';
			toggle.focus();
		}

		toggle.addEventListener( 'click', open );
		if ( close ) {
			close.addEventListener( 'click', closeMenu );
		}
		menu.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key ) {
				closeMenu();
			}
		} );
	}

	/* ---------------------------------------------------------- */
	/* Search overlay + live results                                */
	/* ---------------------------------------------------------- */
	function initSearchOverlay() {
		var toggle    = document.querySelector( '.search-toggle' );
		var overlay   = document.getElementById( 'search-overlay' );
		var close     = overlay ? overlay.querySelector( '.search-close' ) : null;
		var input     = document.getElementById( 'strikehub-search-input' );
		var resultsEl = document.getElementById( 'search-live-results' );

		if ( ! toggle || ! overlay ) {
			return;
		}

		function open() {
			overlay.classList.add( 'is-open' );
			overlay.setAttribute( 'aria-hidden', 'false' );
			toggle.setAttribute( 'aria-expanded', 'true' );
			if ( input ) {
				setTimeout( function () { input.focus(); }, 50 );
			}
		}
		function closeOverlay() {
			overlay.classList.remove( 'is-open' );
			overlay.setAttribute( 'aria-hidden', 'true' );
			toggle.setAttribute( 'aria-expanded', 'false' );
			toggle.focus();
		}

		toggle.addEventListener( 'click', open );
		if ( close ) {
			close.addEventListener( 'click', closeOverlay );
		}
		overlay.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key ) {
				closeOverlay();
			}
		} );

		if ( input && resultsEl && window.StrikeHubAjax ) {
			var timer = null;
			input.addEventListener( 'input', function () {
				clearTimeout( timer );
				var term = input.value.trim();
				if ( term.length < 2 ) {
					resultsEl.innerHTML = '';
					return;
				}
				timer = setTimeout( function () {
					var body = new URLSearchParams();
					body.set( 'action', 'strikehub_search' );
					body.set( 'nonce', window.StrikeHubAjax.nonce );
					body.set( 'term', term );

					fetch( window.StrikeHubAjax.url, { method: 'POST', body: body } )
						.then( function ( r ) { return r.json(); } )
						.then( function ( json ) {
							if ( ! json.success ) {
								return;
							}
							var results = json.data.results || [];
							if ( ! results.length ) {
								resultsEl.innerHTML = '<p class="no-data">' + ( window.StrikeHubL10n && window.StrikeHubL10n.noResults ? window.StrikeHubL10n.noResults : 'No results.' ) + '</p>';
								return;
							}
							var html = '';
							results.forEach( function ( r ) {
								html += '<a href="' + r.url + '"><span class="result-type">' + r.type + '</span>' + r.title + '</a>';
							} );
							resultsEl.innerHTML = html;
						} )
						.catch( function () {} );
				}, 250 );
			} );
		}
	}

	/* ---------------------------------------------------------- */
	/* Tabs (used by Match Center, Event page)                       */
	/* ---------------------------------------------------------- */
	function initTabs() {
		document.querySelectorAll( '[data-tabs]' ).forEach( function ( wrap ) {
			var buttons = wrap.querySelectorAll( '.tab-btn' );
			buttons.forEach( function ( btn ) {
				btn.addEventListener( 'click', function () {
					var target = btn.getAttribute( 'data-tab' );

					buttons.forEach( function ( b ) {
						b.classList.remove( 'is-active' );
						b.setAttribute( 'aria-selected', 'false' );
					} );
					btn.classList.add( 'is-active' );
					btn.setAttribute( 'aria-selected', 'true' );

					wrap.querySelectorAll( '[data-tab-panel]' ).forEach( function ( panel ) {
						panel.hidden = panel.getAttribute( 'data-tab-panel' ) !== target;
					} );
				} );
			} );
		} );
	}

	/* ---------------------------------------------------------- */
	/* Back to top                                                    */
	/* ---------------------------------------------------------- */
	function initBackToTop() {
		var btn = document.getElementById( 'back-to-top' );
		if ( ! btn ) {
			return;
		}
		var io = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( entry ) {
				btn.classList.toggle( 'is-visible', ! entry.isIntersecting );
			} );
		} );
		var sentinel = document.createElement( 'div' );
		document.body.prepend( sentinel );
		io.observe( sentinel );

		btn.addEventListener( 'click', function () {
			window.scrollTo( { top: 0, behavior: reducedMotion ? 'auto' : 'smooth' } );
		} );
	}

	/* ---------------------------------------------------------- */
	/* Match countdowns                                               */
	/* ---------------------------------------------------------- */
	function initCountdowns() {
		var els = document.querySelectorAll( '[data-countdown]' );
		if ( ! els.length ) {
			return;
		}

		function pad( n ) {
			return String( n ).padStart( 2, '0' );
		}

		function tick() {
			var now = Date.now();
			els.forEach( function ( el ) {
				var target = new Date( el.getAttribute( 'data-countdown' ) ).getTime();
				if ( isNaN( target ) ) {
					return;
				}
				var diff = target - now;
				if ( diff <= 0 ) {
					el.textContent = el.dataset.originalText || el.textContent;
					return;
				}
				if ( ! el.dataset.originalText ) {
					el.dataset.originalText = el.textContent;
				}
				var h = Math.floor( diff / 3600000 );
				var m = Math.floor( ( diff % 3600000 ) / 60000 );
				var s = Math.floor( ( diff % 60000 ) / 1000 );
				el.textContent = pad( h ) + ':' + pad( m ) + ':' + pad( s );
			} );
		}

		tick();
		setInterval( tick, 1000 );
	}

	/* ---------------------------------------------------------- */
	/* Breaking ticker: pause on hover/focus (extra to CSS :hover)   */
	/* ---------------------------------------------------------- */
	function initTicker() {
		var track = document.querySelector( '.breaking-track' );
		if ( ! track ) {
			return;
		}
		track.addEventListener( 'focusin', function () { track.classList.add( 'is-paused' ); } );
		track.addEventListener( 'focusout', function () { track.classList.remove( 'is-paused' ); } );
	}

	/* ---------------------------------------------------------- */
	/* Copy-link button on single articles                            */
	/* ---------------------------------------------------------- */
	function initCopyLink() {
		document.querySelectorAll( '[data-copy-link]' ).forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				var url = btn.getAttribute( 'data-copy-link' );
				if ( navigator.clipboard ) {
					navigator.clipboard.writeText( url ).then( function () {
						var original = btn.textContent;
						btn.textContent = 'Copied!';
						setTimeout( function () { btn.textContent = original; }, 1500 );
					} );
				}
			} );
		} );
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		initMobileMenu();
		initSearchOverlay();
		initTabs();
		initBackToTop();
		initCountdowns();
		initTicker();
		initCopyLink();
	} );
} )();
