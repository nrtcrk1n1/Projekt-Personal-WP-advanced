/**
 * StrikeHub ajax.js
 * Handles AJAX-powered filter forms (matches, news, players) and the
 * Top 10 Teams Today refresh button. Uses fetch()/async-await only.
 */
( function () {
	'use strict';

	function serialize( form ) {
		var data = new FormData( form );
		var params = new URLSearchParams();
		data.forEach( function ( value, key ) {
			params.set( key, value );
		} );
		return params;
	}

	async function submitFilter( form ) {
		if ( ! window.StrikeHubAjax ) {
			return;
		}
		var type = form.getAttribute( 'data-ajax-filter' );
		var actionMap = {
			matches: 'strikehub_filter_matches',
			news: 'strikehub_filter_news',
			players: 'strikehub_filter_players',
		};
		var resultsMap = {
			matches: 'match-filter-results',
			news: 'news-filter-results',
			players: 'player-filter-results',
		};
		var action = actionMap[ type ];
		var target = document.getElementById( resultsMap[ type ] );
		if ( ! action || ! target ) {
			return;
		}

		var params = serialize( form );
		params.set( 'action', action );
		params.set( 'nonce', window.StrikeHubAjax.nonce );

		target.setAttribute( 'aria-busy', 'true' );

		try {
			var res  = await fetch( window.StrikeHubAjax.url, { method: 'POST', body: params } );
			var json = await res.json();
			if ( json && json.success ) {
				target.innerHTML = json.data.html;
			}
		} catch ( err ) {
			// Leave existing results in place on network failure.
		} finally {
			target.removeAttribute( 'aria-busy' );
		}
	}

	function initFilters() {
		document.querySelectorAll( '[data-ajax-filter]' ).forEach( function ( form ) {
			form.addEventListener( 'submit', function ( e ) {
				e.preventDefault();
				submitFilter( form );
			} );
			form.querySelectorAll( 'select, input' ).forEach( function ( field ) {
				field.addEventListener( 'change', function () {
					submitFilter( form );
				} );
			} );
		} );
	}

	async function refreshRankings( btn ) {
		if ( ! window.StrikeHubAjax ) {
			return;
		}
		var widget = btn.closest( '.cs2-widget' );
		if ( ! widget ) {
			return;
		}

		btn.classList.add( 'is-loading' );
		btn.disabled = true;

		var params = new URLSearchParams();
		params.set( 'action', 'cs2_refresh_daily_rankings' );
		params.set( 'nonce', window.StrikeHubAjax.nonce );

		try {
			var res  = await fetch( window.StrikeHubAjax.url, { method: 'POST', body: params } );
			var json = await res.json();
			if ( json && json.success ) {
				widget.outerHTML = json.data.html;
			}
		} catch ( err ) {
			// Keep the current widget contents if the request fails.
		} finally {
			var freshBtn = document.querySelector( '.cs2-top-teams .refresh-btn' );
			if ( freshBtn ) {
				freshBtn.classList.remove( 'is-loading' );
				freshBtn.disabled = false;
			}
		}
	}

	function initRefreshButtons() {
		document.body.addEventListener( 'click', function ( e ) {
			var btn = e.target.closest( '[data-action="cs2_refresh_daily_rankings"]' );
			if ( btn ) {
				refreshRankings( btn );
			}
		} );
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		initFilters();
		initRefreshButtons();
	} );
} )();
