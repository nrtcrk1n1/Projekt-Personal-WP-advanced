/**
 * StrikeHub slider.js
 * Dependency-free carousel: autoplay, pause-on-hover, touch swipe,
 * keyboard navigation, dot indicators. Works on any [data-slider] element
 * containing .slide children inside .slider-track.
 */
( function () {
	'use strict';

	var reducedMotion = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

	function StrikeHubSlider( root ) {
		this.root   = root;
		this.track  = root.querySelector( '.slider-track' );
		this.slides = Array.prototype.slice.call( root.querySelectorAll( '.slide' ) );
		this.dots   = Array.prototype.slice.call( root.querySelectorAll( '.slider-dot' ) );
		this.prevBtn = root.querySelector( '.slider-prev' );
		this.nextBtn = root.querySelector( '.slider-next' );
		this.index  = 0;
		this.timer  = null;
		this.interval = 6000;

		if ( this.slides.length < 2 ) {
			return; // Nothing to slide.
		}

		this.bind();
		if ( ! reducedMotion ) {
			this.play();
		}
	}

	StrikeHubSlider.prototype.show = function ( index ) {
		if ( index < 0 ) {
			index = this.slides.length - 1;
		}
		if ( index >= this.slides.length ) {
			index = 0;
		}
		this.slides.forEach( function ( slide, i ) {
			slide.hidden = i !== index;
		} );
		this.dots.forEach( function ( dot, i ) {
			dot.classList.toggle( 'is-active', i === index );
			dot.setAttribute( 'aria-selected', i === index ? 'true' : 'false' );
		} );
		this.index = index;
	};

	StrikeHubSlider.prototype.next = function () {
		this.show( this.index + 1 );
	};

	StrikeHubSlider.prototype.prev = function () {
		this.show( this.index - 1 );
	};

	StrikeHubSlider.prototype.play = function () {
		var self = this;
		this.stop();
		this.timer = setInterval( function () { self.next(); }, this.interval );
	};

	StrikeHubSlider.prototype.stop = function () {
		if ( this.timer ) {
			clearInterval( this.timer );
			this.timer = null;
		}
	};

	StrikeHubSlider.prototype.bind = function () {
		var self = this;

		if ( this.nextBtn ) {
			this.nextBtn.addEventListener( 'click', function () { self.next(); self.play(); } );
		}
		if ( this.prevBtn ) {
			this.prevBtn.addEventListener( 'click', function () { self.prev(); self.play(); } );
		}
		this.dots.forEach( function ( dot, i ) {
			dot.addEventListener( 'click', function () { self.show( i ); self.play(); } );
		} );

		// Pause on hover / focus.
		this.root.addEventListener( 'mouseenter', function () { self.stop(); } );
		this.root.addEventListener( 'mouseleave', function () { if ( ! reducedMotion ) { self.play(); } } );
		this.root.addEventListener( 'focusin', function () { self.stop(); } );
		this.root.addEventListener( 'focusout', function () { if ( ! reducedMotion ) { self.play(); } } );

		// Keyboard navigation.
		this.root.setAttribute( 'tabindex', '0' );
		this.root.addEventListener( 'keydown', function ( e ) {
			if ( 'ArrowLeft' === e.key ) {
				self.prev();
				self.play();
			} else if ( 'ArrowRight' === e.key ) {
				self.next();
				self.play();
			}
		} );

		// Touch swipe.
		var startX = null;
		this.track.addEventListener( 'touchstart', function ( e ) {
			startX = e.touches[0].clientX;
		}, { passive: true } );
		this.track.addEventListener( 'touchend', function ( e ) {
			if ( null === startX ) {
				return;
			}
			var diff = e.changedTouches[0].clientX - startX;
			if ( Math.abs( diff ) > 40 ) {
				if ( diff < 0 ) {
					self.next();
				} else {
					self.prev();
				}
				self.play();
			}
			startX = null;
		}, { passive: true } );
	};

	document.addEventListener( 'DOMContentLoaded', function () {
		document.querySelectorAll( '[data-slider]' ).forEach( function ( el ) {
			new StrikeHubSlider( el ); // eslint-disable-line no-new
		} );
	} );
} )();
