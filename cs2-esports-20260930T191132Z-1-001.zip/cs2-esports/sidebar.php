<?php
/**
 * Sidebar. Chooses the most specific registered widget area for the
 * current context, falling back to the Main Sidebar.
 *
 * @package StrikeHub
 */

if ( is_front_page() ) {
	$area = 'homepage-sidebar';
} elseif ( is_singular( 'cs2_match' ) || is_post_type_archive( 'cs2_match' ) ) {
	$area = 'match-sidebar';
} elseif ( is_singular( 'player' ) || is_post_type_archive( 'player' ) ) {
	$area = 'player-sidebar';
} elseif ( is_singular( 'team' ) || is_post_type_archive( 'team' ) ) {
	$area = 'team-sidebar';
} elseif ( is_singular( 'event' ) || is_post_type_archive( 'event' ) ) {
	$area = 'event-sidebar';
} elseif ( is_singular( 'post' ) || is_home() || is_category() ) {
	$area = 'news-sidebar';
} else {
	$area = 'main-sidebar';
}

if ( ! is_active_sidebar( $area ) && 'main-sidebar' !== $area ) {
	$area = 'main-sidebar';
}
?>
<aside id="secondary" class="widget-area" aria-label="<?php esc_attr_e( 'Sidebar', 'strikehub' ); ?>">
	<?php if ( is_active_sidebar( $area ) ) : ?>
		<?php dynamic_sidebar( $area ); ?>
	<?php else : ?>
		<?php get_template_part( 'template-parts/widgets/top-teams', null, array( 'teams' => cs2_get_top_teams_today( 10 ), 'mode' => 'expanded' ) ); ?>
	<?php endif; ?>
</aside>
