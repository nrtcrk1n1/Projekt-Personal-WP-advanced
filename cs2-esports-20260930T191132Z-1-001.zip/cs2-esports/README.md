# StrikeHub — CS2 Esports News & Statistics Theme

A dark, dense esports-news WordPress theme built with plain PHP, native
WordPress APIs, HTML5, CSS3, and vanilla JavaScript. No third-party
plugins, no page builders, no frontend frameworks.

## Installation

1. Zip the `cs2-esports` folder if it isn't already, or copy it directly
   into `/wp-content/themes/` on your WordPress install.
2. In wp-admin, go to **Appearance → Themes** and activate **StrikeHub**.
3. Go to **Settings → Permalinks** and click **Save Changes** once (this
   registers pretty URLs for Players, Teams, Events, Matches).
4. Go to **Settings → Reading** and set a static homepage if you want a
   separate "Posts" page — `front-page.php` is the main homepage,
   `home.php` is the blog index.

## Content types

The theme registers five custom post types, each with an admin meta box
of fields (Players, Teams, Matches, Events, Transfers) — see
`inc/meta-boxes.php` for the exact field list. Regular **Posts** are used
for news articles; create categories such as "Breaking News",
"Editorials", "Interviews", "Match Reports" to organize them.

## Rankings

**CS2 Dashboard → Ranking Settings** (top-level admin menu) lets you:

- Edit the scoring weights used by `cs2_calculate_team_daily_score()`
- Choose how many recent matches "Teams on Fire" considers
- Enable the public read-only REST API at `/wp-json/cs2/v1/...`
- Manually recalculate today's rankings

Rankings are cached once per day via WordPress transients and recompute
automatically the next day, or immediately after you save a match result
(the cache is cleared on save).

## Widgets & shortcodes

Eleven widgets are registered under **Appearance → Widgets** (Top 10
Teams, Players of the Day, Matches Today, Upcoming Matches, Recent
Results, World Ranking, Teams on Fire, Rising Teams, Trending, Latest
News, Form Guide) across nine widget areas. The same data is available as
shortcodes: `[cs2_top_teams]`, `[cs2_players_of_day]`,
`[cs2_matches_today]`, `[cs2_trending]`, `[cs2_team_form team="123"]`.

## No fake data

If a widget, table, or stat has nothing real behind it, the theme prints
"No data available" instead of inventing a number. Populate teams,
players, and matches with real meta values to see the rankings and
widgets come alive.

## File map

See the top of this repo for the full directory listing; `inc/` holds all
non-template PHP logic, `template-parts/` holds reusable card/widget
markup, and `assets/` holds the three CSS files and three JS files that
power the whole front end.
