<?php
/**
 * Match archive with AJAX filters (date, event, team, status).
 *
 * @package StrikeHub
 */

get_header();
$events = get_posts( array( 'post_type' => 'event', 'posts_per_page' => -1 ) );
?>
<div class="layout-three-col">
	<main id="main" class="main-content">
		<?php strikehub_breadcrumbs(); ?>
		<h1 class="archive-title"><?php esc_html_e( 'Matches', 'strikehub' ); ?></h1>

		<form class="filter-bar" data-ajax-filter="matches">
			<label class="screen-reader-text" for="match-filter-status"><?php esc_html_e( 'Status', 'strikehub' ); ?></label>
			<select id="match-filter-status" name="status">
				<option value=""><?php esc_html_e( 'All Statuses', 'strikehub' ); ?></option>
				<option value="upcoming"><?php esc_html_e( 'Upcoming', 'strikehub' ); ?></option>
				<option value="live"><?php esc_html_e( 'Live', 'strikehub' ); ?></option>
				<option value="final"><?php esc_html_e( 'Final', 'strikehub' ); ?></option>
				<option value="postponed"><?php esc_html_e( 'Postponed', 'strikehub' ); ?></option>
				<option value="cancelled"><?php esc_html_e( 'Cancelled', 'strikehub' ); ?></option>
			</select>

			<label class="screen-reader-text" for="match-filter-event"><?php esc_html_e( 'Event', 'strikehub' ); ?></label>
			<select id="match-filter-event" name="event">
				<option value=""><?php esc_html_e( 'All Events', 'strikehub' ); ?></option>
				<?php foreach ( $events as $event ) : ?>
					<option value="<?php echo esc_attr( $event->ID ); ?>"><?php echo esc_html( $event->post_title ); ?></option>
				<?php endforeach; ?>
			</select>

			<label class="screen-reader-text" for="match-filter-date"><?php esc_html_e( 'Date', 'strikehub' ); ?></label>
			<input type="date" id="match-filter-date" name="date">
		</form>

		<div class="match-grid" id="match-filter-results">
			<?php if ( have_posts() ) : ?>
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/match-card' );
				endwhile;
				?>
			<?php else : ?>
				<?php strikehub_no_data(); ?>
			<?php endif; ?>
		</div>

		<?php strikehub_pagination(); ?>
	</main>

	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
