<?php
/**
 * Event/tournament archive.
 *
 * @package StrikeHub
 */

get_header();
?>
<div class="layout-three-col">
	<main id="main" class="main-content">
		<?php strikehub_breadcrumbs(); ?>
		<h1 class="archive-title"><?php esc_html_e( 'Events', 'strikehub' ); ?></h1>

		<div class="event-grid">
			<?php if ( have_posts() ) : ?>
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/event-card' );
				endwhile;
				?>
			<?php else : ?>
				<?php strikehub_no_data(); ?>
			<?php endif; ?>
		</div>

		<?php strikehub_pagination(); ?>
	</main>

	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
