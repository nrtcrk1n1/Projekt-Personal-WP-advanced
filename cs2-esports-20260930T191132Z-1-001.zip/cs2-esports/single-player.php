<?php
/**
 * Single player profile.
 *
 * @package StrikeHub
 */

get_header();

while ( have_posts() ) :
	the_post();
	$id      = get_the_ID();
	$nick    = strikehub_meta( $id, '_nickname', get_the_title() );
	$real    = strikehub_meta( $id, '_real_name' );
	$country = strikehub_meta( $id, '_country' );
	$team_id = (int) strikehub_meta( $id, '_team_id' );
	$role_terms = get_the_terms( $id, 'player_role' );
	$role    = ( $role_terms && ! is_wp_error( $role_terms ) ) ? $role_terms[0]->name : strikehub_meta( $id, '_weapon' );

	$stats = array(
		'rating'        => strikehub_meta( $id, '_rating' ),
		'kd'            => strikehub_meta( $id, '_kd' ),
		'adr'           => strikehub_meta( $id, '_adr' ),
		'kast'          => strikehub_meta( $id, '_kast' ),
		'hs_pct'        => strikehub_meta( $id, '_hs_pct' ),
		'maps_played'   => strikehub_meta( $id, '_maps_played' ),
		'rounds_played' => strikehub_meta( $id, '_rounds_played' ),
		'total_kills'   => strikehub_meta( $id, '_total_kills' ),
		'total_deaths'  => strikehub_meta( $id, '_total_deaths' ),
		'clutches'      => strikehub_meta( $id, '_clutches' ),
		'aces'          => strikehub_meta( $id, '_aces' ),
	);
	$stat_labels = array(
		'rating'        => __( 'Rating', 'strikehub' ),
		'kd'            => __( 'K/D', 'strikehub' ),
		'adr'           => __( 'ADR', 'strikehub' ),
		'kast'          => __( 'KAST %', 'strikehub' ),
		'hs_pct'        => __( 'Headshot %', 'strikehub' ),
		'maps_played'   => __( 'Maps Played', 'strikehub' ),
		'rounds_played' => __( 'Rounds Played', 'strikehub' ),
		'total_kills'   => __( 'Total Kills', 'strikehub' ),
		'total_deaths'  => __( 'Total Deaths', 'strikehub' ),
		'clutches'      => __( 'Clutches', 'strikehub' ),
		'aces'          => __( 'Aces', 'strikehub' ),
	);
	?>
	<div class="layout-three-col">
		<main id="main" class="main-content">
			<?php strikehub_breadcrumbs(); ?>

			<header class="profile-header player-profile-header">
				<div class="profile-photo">
					<?php if ( has_post_thumbnail() ) : ?>
						<?php the_post_thumbnail( 'strikehub-card' ); ?>
					<?php endif; ?>
				</div>
				<div class="profile-info">
					<h1 class="profile-nickname"><?php echo esc_html( $nick ); ?></h1>
					<?php if ( $real ) : ?><p class="profile-realname"><?php echo esc_html( $real ); ?></p><?php endif; ?>
					<p class="profile-tagline">
						<?php echo esc_html( strikehub_flag( $country ) ); ?>
						<?php echo esc_html( $country ); ?>
						<?php if ( $role ) : ?><span aria-hidden="true">&middot;</span> <?php echo esc_html( $role ); ?><?php endif; ?>
					</p>
					<?php if ( $team_id ) : ?>
						<p class="profile-team">
							<?php esc_html_e( 'Current Team:', 'strikehub' ); ?>
							<a href="<?php echo esc_url( get_permalink( $team_id ) ); ?>"><?php echo esc_html( get_the_title( $team_id ) ); ?></a>
						</p>
					<?php endif; ?>
					<div class="profile-social">
						<?php $tw = strikehub_meta( $id, '_social_twitter' ); ?>
						<?php $tv = strikehub_meta( $id, '_social_twitch' ); ?>
						<?php if ( $tw ) : ?><a href="<?php echo esc_url( $tw ); ?>" rel="noopener" target="_blank"><?php esc_html_e( 'Twitter / X', 'strikehub' ); ?></a><?php endif; ?>
						<?php if ( $tv ) : ?><a href="<?php echo esc_url( $tv ); ?>" rel="noopener" target="_blank"><?php esc_html_e( 'Twitch', 'strikehub' ); ?></a><?php endif; ?>
					</div>
				</div>
			</header>

			<section class="stat-grid-section">
				<h2><?php esc_html_e( 'Statistics', 'strikehub' ); ?></h2>
				<?php
				$has_stats = false;
				foreach ( $stats as $v ) {
					if ( '' !== $v ) {
						$has_stats = true;
						break;
					}
				}
				?>
				<?php if ( $has_stats ) : ?>
					<div class="stat-grid">
						<?php foreach ( $stats as $key => $value ) : ?>
							<?php if ( '' !== $value ) : ?>
								<div class="stat-tile">
									<span class="stat-value"><?php echo esc_html( $value ); ?></span>
									<span class="stat-label"><?php echo esc_html( $stat_labels[ $key ] ); ?></span>
								</div>
							<?php endif; ?>
						<?php endforeach; ?>
					</div>
				<?php else : ?>
					<?php strikehub_no_data(); ?>
				<?php endif; ?>
			</section>

			<?php if ( get_the_content() ) : ?>
				<section class="profile-bio">
					<h2><?php esc_html_e( 'Biography', 'strikehub' ); ?></h2>
					<div class="article-content"><?php the_content(); ?></div>
				</section>
			<?php endif; ?>

			<section class="recent-matches-section">
				<h2><?php esc_html_e( 'Recent Matches', 'strikehub' ); ?></h2>
				<?php
				$recent = $team_id ? strikehub_get_team_matches( $team_id, 5 ) : null;
				if ( $recent && $recent->have_posts() ) :
					?>
					<div class="match-grid">
						<?php
						while ( $recent->have_posts() ) :
							$recent->the_post();
							get_template_part( 'template-parts/match-card' );
						endwhile;
						wp_reset_postdata();
						?>
					</div>
					<?php
				else :
					strikehub_no_data();
				endif;
				?>
			</section>

			<section class="recent-news-section">
				<h2><?php esc_html_e( 'Recent News', 'strikehub' ); ?></h2>
				<?php
				$news = new WP_Query( array( 's' => $nick, 'posts_per_page' => 3, 'no_found_rows' => true ) );
				if ( $news->have_posts() ) :
					?>
					<div class="news-grid">
						<?php
						while ( $news->have_posts() ) :
							$news->the_post();
							get_template_part( 'template-parts/news-card' );
						endwhile;
						wp_reset_postdata();
						?>
					</div>
					<?php
				else :
					strikehub_no_data();
				endif;
				?>
			</section>
		</main>

		<?php get_sidebar(); ?>
	</div>
	<?php
endwhile;

get_footer();
